/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUInformarPlanesMaster;


import Modelo.CUInformarPlanesMaster.CUInformarPlanesMasterM;
import Comun.DTO.DTOMaster;
import Logica.CUInformarPlanesMaster.CUInformarPlanesMasterP;
import Persistencia.CUFachadaInformarPlanesMaster;
import Persistencia.FachadaBD;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;


/**
 * Clase CUInformarPlanesMasterMTest con los test de la clase CUInformarPlanesMasterM
 * 
 * @author JAA
 */
public class CUInformarPlanesMasterMTest {
    
    private CUInformarPlanesMasterM modelo;
    @Mock
    private CUInformarPlanesMasterP controlador;
    @Mock
    private CUFachadaInformarPlanesMaster fachada;

    @Mock
    private List<DTOMaster> resultado;
    
    @Before
    public  void setUp(){
        controlador = createMock(CUInformarPlanesMasterP.class);
        fachada = createMock(FachadaBD.class);
        
    }

    @Test(expected = IllegalArgumentException.class)
    public void setFacadeNull(){
       modelo = new CUInformarPlanesMasterM(fachada);
       new CUInformarPlanesMasterM(null);
    }
     
    
    
    @Test 
    public void requestMasterListNoMasters() throws SQLException{
        ArrayList<DTOMaster> resultado = null;
        expect(fachada.requestMasterList()).andReturn(resultado);
        replay(fachada);
        modelo = new CUInformarPlanesMasterM(fachada);
        assertNull(modelo.requestMasterList());
        verify(fachada);
    }
    
    @Test
    public void requestMasterListMasters() throws SQLException{
        resultado=createMock(ArrayList.class);
        expect(fachada.requestMasterList()).andReturn(resultado);
        
        replay(fachada);
        modelo = new CUInformarPlanesMasterM(fachada);
        List listado = modelo.requestMasterList();
        assertNotNull(listado);
        
        verify(fachada);
         
    }
    
}
