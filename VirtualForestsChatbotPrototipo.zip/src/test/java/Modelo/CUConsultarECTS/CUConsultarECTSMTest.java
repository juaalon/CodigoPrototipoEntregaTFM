/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarECTS;

import Persistencia.CUFachadaConsultarECTS;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;

/**
 *
 * @author JAA
 */
public class CUConsultarECTSMTest {
     
   private CUConsultarECTSM modelo;
   @Mock
   private CUFachadaConsultarECTS fachada;
    
    @Before
    public void setUp() {
        fachada = createMock(CUFachadaConsultarECTS.class);
        modelo = new CUConsultarECTSM(fachada);
    }
    
 
    @Test
    public void testGetInfoECTS() {
        expect(fachada.getDescripcionECTS()).andReturn("").times(1);
        replay(fachada);
        modelo.getInfoECTS();
        verify(fachada);
    }
    
}
