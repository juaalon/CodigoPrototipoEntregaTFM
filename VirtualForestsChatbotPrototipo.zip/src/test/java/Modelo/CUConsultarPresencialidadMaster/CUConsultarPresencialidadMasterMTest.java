/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarPresencialidadMaster;

import Modelo.CUConsultarPresencialidadMaster.CUConsultarPresencialidadMasterM;
import Persistencia.CUFachadaConsultarPresencialidadMaster;
import Persistencia.FachadaBD;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;


public class CUConsultarPresencialidadMasterMTest {
  @Mock
    private CUFachadaConsultarPresencialidadMaster fachada;
    private CUConsultarPresencialidadMasterM modelo;
    @Before
    public void setUp() {
        fachada = createMock(FachadaBD.class);
        modelo = new CUConsultarPresencialidadMasterM(fachada);
    }
  
    @Test
    public void testGetPresentacionPresencialidadMaster() {
        expect(fachada.getPresentacionPresencialidadMaster()).andReturn("").times(1);
        replay(fachada);
        modelo.getPresentacionPresencialidadMaster();
        verify(fachada);
    }
 
    @Test
    public void testGetPresencialidadMaster() {
        String programa="Montes";
        expect(fachada.getPresencialidadMaster(programa)).andReturn("").times(1);
        replay(fachada);
        modelo.getPresencialidadMaster(programa);
        verify(fachada);
    }
 
    @Test
    public void testGetExcepcionalidadPresencialidad() {
        expect(fachada.getExcepcionalidadPresencialidadMaster()).andReturn("").times(1);
        replay(fachada);
        modelo.getExcepcionalidadPresencialidad();
        verify(fachada);
    }
    
}
