/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarColaboracionesMaster;

import Comun.DTO.DTOColaboracion;
import Persistencia.CUFachadaConsultarColaboraciones;
import Persistencia.FachadaBD;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.easymock.EasyMock;

import org.easymock.IAnswer;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.anyDouble;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.IAnswer;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class CUConsultarColaboracionesMasterMTest {
    @Mock
    private CUFachadaConsultarColaboraciones fachada;
    
    private CUConsultarColaboracionesMasterM modelo;
    
    @Before
    public void setUp() {
        fachada = createMock(FachadaBD.class);
        modelo = new CUConsultarColaboracionesMasterM(fachada);
    }
    
 
    @Test
    public void testGetColaboraciones() {
        String programa="Montes";
        expect(fachada.getColaboracionesMaster(programa)).andReturn(null).times(1);
        replay(fachada);
        modelo.getColaboraciones(programa);
        verify(fachada);
    }
 
    @Test
    public void testGetPresentacionColaboraciones() {
 
        expect(fachada.getPresentacionColaboraciones()).andReturn(null).times(1);
        replay(fachada);
        modelo.getPresentacionColaboraciones();
        verify(fachada);
    }
 
    @Test
    public void testGetPlantillaColaboracion() {
 
        expect(fachada.getPlantillaColaboracion()).andReturn(null).times(1);
        replay(fachada);
        modelo.getPlantillaColaboracion();
        verify(fachada);
    }
 
    @Test
    public void testGetMensajeColaboracionesNulas() {
     
        expect(fachada.getMensajeNoHayColaboraciones()).andReturn(null).times(1);
        replay(fachada);
        modelo.getMensajeColaboracionesNulas();
        verify(fachada);
    }
    
}
