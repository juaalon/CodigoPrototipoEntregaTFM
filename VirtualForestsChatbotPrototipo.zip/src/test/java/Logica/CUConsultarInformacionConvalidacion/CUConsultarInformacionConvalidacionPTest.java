/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarInformacionConvalidacion;

import Modelo.CUConsultarInformacionConvalidacion.CUModeloConsultarInformacionConvalidacion;
import java.util.ArrayList;
import java.util.List;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import org.easymock.Mock;
 
import org.junit.Before;
 
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author usuario
 */
public class CUConsultarInformacionConvalidacionPTest {
    
    @Mock 
    private CUModeloConsultarInformacionConvalidacion modelo;
    private CUConsultarInformacionConvalidacionP presentador;
    @Before
    public void setUp() {
        modelo = createMock(CUModeloConsultarInformacionConvalidacion.class);
        presentador = new CUConsultarInformacionConvalidacionP(modelo);
    }
     
    
    @Test
    public void testConsultarProcesoConvalidacion() {
        expect(modelo.consultarConvalidacion()).andReturn("").times(1);
        replay(modelo);
        presentador.consultarProcesoConvalidacion();
        verify(modelo);
    }
    
}
