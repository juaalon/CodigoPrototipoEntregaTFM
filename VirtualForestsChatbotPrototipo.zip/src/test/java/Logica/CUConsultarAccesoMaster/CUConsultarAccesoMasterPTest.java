/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarAccesoMaster;

import Comun.DTO.DTOColaboracion;
import Modelo.CUConsultarAccesoMaster.CUConsultarAccesoMasterM;
import Modelo.CUConsultarAccesoMaster.CUModeloConsultarAccesoMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;
/**
 *
 * @author JAA
 */
public class CUConsultarAccesoMasterPTest {
    @Mock
    private  CULogicaConsultarAccesoMaster control;
     @Mock  
    private ArrayList array;
     @Mock  
    private  DTOColaboracion dtoColab;
    private  CUModeloConsultarAccesoMaster modelo;
   
    @Before
    public void setUp() {
        modelo = createMock(CUConsultarAccesoMasterM.class);
        control = new CUConsultarAccesoMasterP(modelo);
        array = createMock(ArrayList.class);
        dtoColab = createMock(DTOColaboracion.class);
       
    }
    
     @Test (expected=IllegalArgumentException.class)
    public void determinarPosibilidadAccesoTestProgramaNull(){
        
        control.tratarDialogoAccesoMaster(null, null,null);
            
    }
    @Test (expected=IllegalArgumentException.class)
    public void determinarPosibilidadAccesoNull(){
        
        control.tratarDialogoAccesoMaster("", null,true);
            
    }
    @Test
    public void determinarPosibilidadAccesoNacionalidadSpain(){
        expect(modelo.getRespuestaPosesionGraduado("Montes")).andReturn("").times(1);
        replay(modelo);
        control.tratarDialogoAccesoMaster("Montes", "España",null);
        verify(modelo);         
    }
    @Test
    public void determinarPosibilidadAccesoNacionalidadExtranjeraHmlgd(){
        expect(modelo.getRequisitoHomologacionAccesoMaster("Montes")).andReturn(true).times(1);
        expect(modelo.getRespuestaSolicitudTituloCompatibleHomologado("Montes")).andReturn("").times(1);
        replay(modelo);
        control.tratarDialogoAccesoMaster("Montes", "Vietnam",null);
        verify(modelo);         
    }
    
    @Test
    public void determinarPosibilidadAccesoNacionalidadExtranjeraNoHmlgd(){
        expect(modelo.getRequisitoHomologacionAccesoMaster("Montes")).andReturn(false).times(1);
        expect(modelo.getRespuestaPosesionGraduadoUniversitario()).andReturn("").times(1);
        replay(modelo);
        control.tratarDialogoAccesoMaster("Montes", "Vietnam",null);
        verify(modelo);         
    }
    
    @Test
    public void validarAccesoUsuarioSpainSinTitulo(){
         
        expect(modelo.getProgramasAlternativos()).andReturn(new ArrayList()).times(1);
        expect(modelo.getRespuestaNoAccesoMaster("Montes")).andReturn("").times(1);
        replay(modelo);
        control.tratarDialogoAccesoMaster("Montes", "España",false);
        verify(modelo);         
    }
    @Test
    public void validarAccesoUsuarioSpainConTituloColab(){
      
       
        expect(modelo.getRespuestaAccesoMaster("Montes")).andReturn("").times(1);
         
        
        replay(modelo);
        
         
        String resp = control.tratarDialogoAccesoMaster("Montes", "España",true);
        
        verify(modelo);  
         
    }
    @Test
    public void validarAccesoUsuarioSpainConTituloNoColab(){
      
         
        expect(modelo.getRespuestaAccesoMaster("Montes")).andReturn("").times(1);
        
        replay(modelo);
 
        String resp = control.tratarDialogoAccesoMaster("Montes", "España",true);
        
        verify(modelo);  
        
    }
     @Test
    public void validarAccesoUsuarioExtrConTituloColab(){
       expect(modelo.getColaboracionesMaster("Montes")).andReturn(array).times(1);
       expect(modelo.getRequisitoHomologacionAccesoMaster("Montes")).andReturn(true).times(1);
        expect(modelo.getRespuestaAccesoMaster("Montes")).andReturn("").times(1);
        expect(modelo.getRespuestaPresentacionColaboraciones()).andReturn("").times(1);

        expect(array.size()).andReturn(1).times(2);
        expect(array.get(0)).andReturn(dtoColab).times(1);
        expect(dtoColab.getEntidad()).andReturn("1").times(1);
        replay(modelo);
        replay(array);
        replay(dtoColab);
        String resp = control.tratarDialogoAccesoMaster("Montes", "Vietnam",true);
        assertTrue(resp.contains("1"));
        verify(modelo);  
        verify(array);
        verify(dtoColab);
        
    }
     @Test
    public void validarAccesoUsuarioExtrConTituloNoColab(){
        
       expect(modelo.getRequisitoHomologacionAccesoMaster("Montes")).andReturn(true).times(1);
         expect(modelo.getColaboracionesMaster("Montes")).andReturn(null).times(1);
        expect(modelo.getRespuestaAccesoMaster("Montes")).andReturn("").times(1);
        
        replay(modelo);
 
        String resp = control.tratarDialogoAccesoMaster("Montes", "Vietnam",true);
        
        verify(modelo);  
        
        
    }
     @Test
    public void validarAccesoUsuarioExtrSintitulo(){
       expect(modelo.getProgramasAlternativos()).andReturn(array).times(1);
       expect(modelo.getRequisitoHomologacionAccesoMaster("Montes")).andReturn(true).times(1);
        expect(modelo.getRespuestaAccesoMasterNoHomologado("Montes")).andReturn("").times(1);
        expect(array.size()).andReturn(0).times(1);
         
        replay(modelo);
        replay(array);
        replay(dtoColab);
        String resp = control.tratarDialogoAccesoMaster("Montes", "Vietnam",false);
        
        verify(modelo);  
        verify(array);
        verify(dtoColab);
        
    }
     @Test
    public void validarAccesoUsuarioExtrSintituloSinHomol(){
       expect(modelo.getRespuestaNoAccesoMaster("Dataforest")).andReturn("").times(1);
       expect(modelo.getRequisitoHomologacionAccesoMaster("Dataforest")).andReturn(false).times(1);
    
       
        replay(modelo);
     
        String resp = control.tratarDialogoAccesoMaster("Dataforest", "Vietnam",false);
       
        verify(modelo);  
        
        
    }
     @Test
    public void validarAccesoUsuarioExtrContituloSinHomolConColab(){
       expect(modelo.getColaboracionesMaster("Dataforest")).andReturn(array).times(1);
       expect(modelo.getRequisitoHomologacionAccesoMaster("Dataforest")).andReturn(false).times(1);
        expect(modelo.getRespuestaAccesoMaster("Dataforest")).andReturn("").times(1);
        expect(modelo.getRespuestaPresentacionColaboraciones()).andReturn("").times(1);
        expect(array.size()).andReturn(1).times(2);
        expect(array.get(0)).andReturn(dtoColab).times(1);
        expect(dtoColab.getEntidad()).andReturn("1").times(1);
        replay(modelo);
        replay(array);
        replay(dtoColab);
        String resp = control.tratarDialogoAccesoMaster("Dataforest", "Vietnam",true);
        assertTrue(resp.contains("1"));
        verify(modelo);  
        verify(array);
        verify(dtoColab);
        
        
        
    }
    @Test
    public void validarAccesoUsuarioExtrContituloSinHomolSinColab(){
       expect(modelo.getColaboracionesMaster("Dataforest")).andReturn(null).times(1);
       expect(modelo.getRequisitoHomologacionAccesoMaster("Dataforest")).andReturn(false).times(1);
        expect(modelo.getRespuestaAccesoMaster("Dataforest")).andReturn("").times(1);
        
        replay(modelo);
         
        String resp = control.tratarDialogoAccesoMaster("Dataforest", "Vietnam",true);
        
        verify(modelo);  
         
        
        
    }
}
