/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUInformarPlanesMaster;

import Comun.DTO.DTOMaster;
import Modelo.CUInformarPlanesMaster.CUInformarPlanesMasterM;
import Modelo.CUInformarPlanesMaster.CUModeloInformarPlanesMaster;
import java.util.ArrayList;
import java.util.List;
import org.easymock.Mock;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.*;



/**
 *
 * @author usuario
 */
public class CUInformarPlanesMasterPTest {
    
    @Mock
    private CUModeloInformarPlanesMaster modelo;
    @Mock
    private List<DTOMaster> listado;
    @Mock
    private DTOMaster dtoMaster;
    
    private CUInformarPlanesMasterP control; 
    
    @Before
    public void setUp() {
        modelo = createMock(CUInformarPlanesMasterM.class);
        listado = createMock(ArrayList.class);
        dtoMaster = createMock(DTOMaster.class);
        control = new CUInformarPlanesMasterP(modelo);
    }
    
    
    @Test
    public void testGetListadoMasteres() {
      expect(modelo.requestMasterList()).andReturn(listado).times(1);
      replay(modelo);
      control.getListadoMasteres();
      verify(modelo);
    }
    
    @Test
    public void testGetListadoMasteresList() {
      expect(modelo.requestMasterList()).andReturn(listado).times(1);
      expect(listado.size()).andReturn(1).times(2);
      expect(listado.get(0)).andReturn(dtoMaster).times(1);
      expect(dtoMaster.getNombre()).andReturn("").times(1);
      replay(modelo);
      replay(listado);
      replay(dtoMaster);
      control.getListadoMasteres();
      verify(listado);
      verify(dtoMaster);
      verify(modelo);
    }
    
    @Test
    public void testGetListadoMasteresNull() {
      expect(modelo.requestMasterList()).andReturn(null).times(1);
      replay(modelo);
      assertNull(control.getListadoMasteres());
      verify(modelo);
    }
    
}
