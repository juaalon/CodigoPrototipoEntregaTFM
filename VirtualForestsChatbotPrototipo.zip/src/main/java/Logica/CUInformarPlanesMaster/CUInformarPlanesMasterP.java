/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUInformarPlanesMaster;

import Comun.DTO.DTOMaster;
import Modelo.CUInformarPlanesMaster.CUInformarPlanesMasterM;
import java.util.ArrayList;
import java.util.List;
import Modelo.CUInformarPlanesMaster.CUModeloInformarPlanesMaster;

/**
 * Clase CUInformarPlanesMasterP, implementa el presentador del CU Informar Planes de Máster
 * 
 * @author JAA
 */
public class CUInformarPlanesMasterP implements CULogicaInformarPlanesMaster{
    
    private CUModeloInformarPlanesMaster modelo;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUInformarPlanesMasterP(){
        modelo = new CUInformarPlanesMasterM();
    }
    
    public CUInformarPlanesMasterP(CUModeloInformarPlanesMaster model){
        modelo =  model;
    }
    
    /**
     * Metodo getListadoMasteres, obtiene una respuesta con el listado de másteres disponible.
     * 
     * @return List  con el listado de los másteres disponibles
     */
    @Override
    public List<String> getListadoMasteres() {
        ArrayList<DTOMaster>listado =  (ArrayList<DTOMaster>)  modelo.requestMasterList();
        List<String> response= new ArrayList<String>();
        try{
            for(int i=0;i<listado.size();i++){
                response.add(listado.get(i).getNombre());
            }
        }catch(NullPointerException npexcpt){
            response = null;
        }
        return response;
          
    }
    
}
