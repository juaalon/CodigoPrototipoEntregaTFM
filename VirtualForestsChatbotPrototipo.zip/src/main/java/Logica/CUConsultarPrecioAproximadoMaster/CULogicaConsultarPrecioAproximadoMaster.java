/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarPrecioAproximadoMaster;

/**
 *
 * @author JAA
 */
public interface CULogicaConsultarPrecioAproximadoMaster {

    public String consultarPrecioMaster(String programa);
    
}
