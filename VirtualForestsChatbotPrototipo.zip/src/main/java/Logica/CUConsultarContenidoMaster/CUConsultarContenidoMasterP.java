/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarContenidoMaster;

import Modelo.CUConsultarContenidoMaster.CUConsultarContenidoMasterM;
import Modelo.CUConsultarContenidoMaster.CUModeloConsultarContenidoMaster;

/**
 * Clase CUConsultarContenidoMasterP, implementa la logica del CU Consultar Contenido Master.
 * 
 * 
 * @author JAA
 */
public class CUConsultarContenidoMasterP implements CULogicaConsultarContenidoMaster{

    private CUModeloConsultarContenidoMaster modelo;
    
    /**
     * Constructor de clase
     */
    public CUConsultarContenidoMasterP(){
        modelo = new CUConsultarContenidoMasterM();
    }
    
    public CUConsultarContenidoMasterP(CUModeloConsultarContenidoMaster m){
        modelo = m;
    }
    
    /**
     * Metodo getDescripcionMaster, devuelve una explciacion del contenido del master.
     * 
     * @param programa El programa de master
     * @return String con la cadena
     */
    @Override
    public String getDescripcionMaster(String programa) {
        return modelo.getDescripcionMaster(programa);
    }
    
}
