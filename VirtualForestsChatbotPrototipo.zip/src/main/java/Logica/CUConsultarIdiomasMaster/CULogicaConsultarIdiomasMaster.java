/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarIdiomasMaster;

/**
 *
 * @author usuario
 */
public interface CULogicaConsultarIdiomasMaster {

    public String consultarIdiomasMaster(String programa, String idioma);

    public String consultarIdiomasMaster(String programa);
    
}
