/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.CUConsultarIdiomasMaster;

import Comun.DTO.DTOIdioma;
import Modelo.CUConsultarIdiomasMaster.CUConsultarIdiomasMasterM;
import Modelo.CUConsultarIdiomasMaster.CUModeloConsultarIdiomasMaster;
import java.util.List;

/**
 * Clase CUConsultarIdiomasMasterP, implementa el presentador del CU Consultar Idiomas Master.
 * 
 * 
 * @author JAA
 */
public class CUConsultarIdiomasMasterP implements CULogicaConsultarIdiomasMaster{

    private CUModeloConsultarIdiomasMaster modelo;
    
    /**
     * Cosntructor de clase.
     * 
     */
    public CUConsultarIdiomasMasterP(){
        modelo = new CUConsultarIdiomasMasterM();
    } 
    
    /**
     * Constructor de clase.
     * 
     * @param modelo CUModeloConsultarIdiomasMaster
     */
    public CUConsultarIdiomasMasterP(CUModeloConsultarIdiomasMaster modelo){
        this.modelo = modelo;
    }
    
    /**
     * Metodo consultarIdiomasMaster, obtiene la informacion de idiomas de imparticion de un master.
     * 
     * @param programa String con el programa de master
     * @param idioma String con el idioma de imparticion sobre el que se pregunta
     * @throws IllegalArgumentException si programa es null
     * @return String con la respuesta
     */
    @Override
    public String consultarIdiomasMaster(String programa, String idioma) throws IllegalArgumentException {
        return consultarNivelIdiomas(programa,idioma);
    }
    
    /**
     * Metodo consultarIdiomasMaster, obtiene la informacion de idiomas de imparticion de un master.
     * 
     * @param programa String con el programa de master
     * @throws IllegalArgumentException si programa es null
     * @return String con la respuesta
     */
    @Override
    public String consultarIdiomasMaster(String programa) throws IllegalArgumentException{
        return consultarNivelIdiomas(programa, null);
    }
    
    private String consultarNivelIdiomas(String programa, String idioma){
        String respuesta = null; 
        if(programa==null){
            throw new IllegalArgumentException();
        }else{
            if(idioma == null){
                    respuesta = obtenerListadoIdiomas(modelo.getRespuestaIdiomasyNivelesMaster(programa));
             }else{
                    respuesta = obtenerListadoIdiomas(modelo.getRespuestaIdiomaEspecificoyNivelesMaster(programa,idioma));
             }
             
            return respuesta;
        }
    
    }

    private String obtenerListadoIdiomas(List<DTOIdioma> idiomas){
        String respuesta="";
        String plantillaIdioma="";
        String tmp="";
        if(idiomas!=null){
           
            respuesta = modelo.getRespuestaIdiomasEncontrados();
            
            plantillaIdioma = modelo.getPlantillaIdioma();
            if(respuesta!=null&&plantillaIdioma!=null){
                for(int i=0;i<idiomas.size();i++){
                    DTOIdioma idioma = idiomas.get(i);
                    tmp = plantillaIdioma.replace("<stub1>", idioma.getDenominacion());
                    tmp = tmp.replace("<stub2>", idioma.getNivelMinimo());
                    tmp = tmp.replace("<stub3>", idioma.getNivelRecomendado());
                    respuesta = respuesta +"\n"+ tmp;
                }
            }else{
                respuesta = null;
            }
            
        }else{
            respuesta = null;
        }
       
        return respuesta;
    }
    
}
