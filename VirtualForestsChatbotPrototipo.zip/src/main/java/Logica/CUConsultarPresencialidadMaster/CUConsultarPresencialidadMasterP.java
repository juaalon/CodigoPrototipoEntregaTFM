 
package Logica.CUConsultarPresencialidadMaster;

import Modelo.CUConsultarPresencialidadMaster.CUConsultarPresencialidadMasterM;
import Modelo.CUConsultarPresencialidadMaster.CUModeloConsultarPresencialidadMaster;

/**
 * Clase CUConsultarPresencialidadMasterP, implementa la logica del CU Consultar 
 * Presencialidad de un Master.
 * 
 * @author JAA
 */
public class CUConsultarPresencialidadMasterP implements CULogicaConsultarPresencialidadMaster{
    
    private CUModeloConsultarPresencialidadMaster modelo;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarPresencialidadMasterP(){
        modelo = new CUConsultarPresencialidadMasterM();
    }
    
    public CUConsultarPresencialidadMasterP(CUModeloConsultarPresencialidadMaster m){
        modelo = m;
    }
    
    /**
     * Metodo consultarPresencialidadMaster, consulta la modalidad de presencialidad
     * del master.
     * 
     * @param programa String nombre programa de master
     * @return String con la respeusta
     */
    @Override
    public String consultarPresencialidadMaster(String programa) {
        String respuesta = null;
        if(programa==null){
            throw new IllegalArgumentException();
        }else{
            String presentacionPresencialidadMaster = modelo.getPresentacionPresencialidadMaster();
            String presencialidadMaster = modelo.getPresencialidadMaster(programa);
            String explicacion = modelo.getExcepcionalidadPresencialidad();
           
            if(presentacionPresencialidadMaster!=null&&presencialidadMaster!=null){
                respuesta = presentacionPresencialidadMaster.replace("<stub1>",programa).replace("<stub2>",presencialidadMaster)+"\n"+explicacion;
            } 
        }
        return respuesta;
    }
}
