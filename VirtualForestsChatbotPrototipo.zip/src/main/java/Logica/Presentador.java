 
 
package Logica;

import Comun.DialogFlowStruct;
import Logica.CUConsultarPresencialidadMaster.CUConsultarPresencialidadMasterP;
import Logica.CUConsultarPresencialidadMaster.CULogicaConsultarPresencialidadMaster;

import Logica.CUConsultarAccesoMaster.CUConsultarAccesoMasterP;
import Logica.CUConsultarAccesoMaster.CULogicaConsultarAccesoMaster;
import Logica.CUConsultarColaboracionesMaster.CUConsultarColaboracionesMasterP;
import Logica.CUConsultarColaboracionesMaster.CULogicaConsultarColaboracionesMaster;
import Logica.CUConsultarCronogramaMaster.CUConsultarCronogramaMasterP;
import Logica.CUConsultarCronogramaMaster.CULogicaConsultarCronogramaMaster;
import Logica.CUConsultarIdiomasMaster.CUConsultarIdiomasMasterP;
import Logica.CUConsultarIdiomasMaster.CULogicaConsultarIdiomasMaster;
import Logica.CUInformarPlanesMaster.CUInformarPlanesMasterP;
import Logica.CUInformarPlanesMaster.CULogicaInformarPlanesMaster;
import Logica.CUConsultarPrecioAproximadoMaster.CUConsultarPrecioAproximadoMasterP;
import Logica.CUConsultarPrecioAproximadoMaster.CULogicaConsultarPrecioAproximadoMaster;
import Logica.CUConsultarContenidoMaster.CUConsultarContenidoMasterP;
import Logica.CUConsultarContenidoMaster.CULogicaConsultarContenidoMaster;
import Logica.CUConsultarCorreoCoordinadorMaster.CUConsultarCorreoCoordinadorMasterP;
import Logica.CUConsultarCorreoCoordinadorMaster.CULogicaConsultarCorreoCoordinadorMaster;
import Logica.CUConsultarECTS.CUConsultarECTSP;
import Logica.CUConsultarECTS.CULogicaConsultarECTS;
import Logica.CUConsultarInformacionConvalidacion.CUConsultarInformacionConvalidacionP;
import Logica.CUConsultarInformacionConvalidacion.CULogicaConsultarInformacionConvalidacion;
import Logica.CUConsultarLenguajesProgramacion.CUConsultarLenguajesProgramacionP;
import Logica.CUConsultarLenguajesProgramacion.CULogicaConsultarLenguajesProgramacion;
import Modelo.ModeloDefaultFallback;
import java.util.List;
import java.util.Map;
 

/**
 * Clase Presentador, principal controlador del sistema que deriva la funcionalidad concreta a otros.
 * 
 * @author JAA
 */
public class Presentador {

    
    private  CULogicaInformarPlanesMaster controlListadoMaster;
    private  CULogicaConsultarAccesoMaster controlConsultarAccesoMaster;
    private  CULogicaConsultarIdiomasMaster controlConsultarIdiomasMaster;
    private  CULogicaConsultarPrecioAproximadoMaster controlConsultarPrecioMaster;
    private  CULogicaConsultarPresencialidadMaster controlPresencialidadMaster;
    private  CULogicaConsultarCronogramaMaster controlCronogramaMaster;
    private  CULogicaConsultarContenidoMaster controlConsultarMaster;
    private  CULogicaConsultarLenguajesProgramacion controlConsultarLenguajesProgramacion;
    private  CULogicaConsultarECTS controlConsultarECTS;
    private  CULogicaConsultarColaboracionesMaster controlColaboracionesMaster;
    private  CULogicaConsultarInformacionConvalidacion controlConsultarConvalidacion;
    private  CULogicaConsultarCorreoCoordinadorMaster controlConsultarCorreoCoordinacion;
    private  ModeloDefaultFallback modeloDefaultFallback;
    
    /**
    * Constructor de clase.
    *
    * 
    */
    public Presentador(){
        controlListadoMaster= new CUInformarPlanesMasterP();
        controlConsultarAccesoMaster = new CUConsultarAccesoMasterP();
        controlConsultarIdiomasMaster = new CUConsultarIdiomasMasterP();
        controlConsultarPrecioMaster = new CUConsultarPrecioAproximadoMasterP();
        controlPresencialidadMaster = new CUConsultarPresencialidadMasterP();
        controlCronogramaMaster = new CUConsultarCronogramaMasterP();
        controlConsultarMaster = new CUConsultarContenidoMasterP();
        controlConsultarLenguajesProgramacion = new CUConsultarLenguajesProgramacionP();
        controlConsultarECTS = new CUConsultarECTSP();
        controlColaboracionesMaster = new CUConsultarColaboracionesMasterP();
        controlConsultarConvalidacion = new CUConsultarInformacionConvalidacionP();
        controlConsultarCorreoCoordinacion = new CUConsultarCorreoCoordinadorMasterP();
        modeloDefaultFallback = new ModeloDefaultFallback();
    }

    
     
    
    /**
     * Metodo getResponseFromPresenter, devuelve la respuesta correspondiente al 
     * intent identificado.
     * 
     * @param objectRequest objeto DialogFlowStruct con los datos de la peticion
     * @return  String con la respuesta
     */
    public String getResponseFromPresenter(DialogFlowStruct objectRequest) {
        
        String response="";
        String intent= objectRequest.getIntent().get("displayName");
        Map<String,String> parameters=objectRequest.getParameters();
        
        if(intent.contains("Masteres_Disponibles")){
             response = consultarDisponibilidadMasteres();          
        }else{
            if(intent.contains("Consultar_Acceso_Master")){          
                response = consultarAccesoMasteres(parameters);    
            }
            else{
                if(intent.contains("Consultar_Nivel_Idiomas_Master")){
                     response = consultarNivelIdiomasMaster(parameters);
                }else{
                    if(intent.contains("Consultar_Precio_Aproximado_Master")){
                         response = consultarPrecioAproximadoMaster(parameters);
                    }else{
                        if(intent.contains("Consultar_Presencialidad_Master")){
                             response = consultarPresencialidadMaster(parameters);
                        }else{
                            if(intent.contains("Consultar_Cronograma_Master")){
                                 response = consultarCronogramaMaster(parameters);
                            }else{
                                if(intent.contains("Solicitar_Resumen_Master")){
                                    response = consultarContenidoMaster(parameters);
                                }else{
                                    if(intent.contains("Consultar_Lenguaje_Programacion_Master")){
                                        response = consultarLProgMaster(parameters);
                                    }else{
                                        if(intent.contains("Consultar_ECTS")){
                                            response = consultarECTS();
                                        }else{
                                            if(intent.contains("Consultar_Informacion_Colaboraciones")){
                                                response = consultarColaboracionesMaster(parameters);
                                            }else{
                                                if(intent.contains("Consultar_Información_Convalidacion")){
                                                    response = consultarInformacionConvalidaciones();
                                                }else{
                                                    if(intent.contains("Consultar_Correo_Contacto")){
                                                        response = consultarCorreoMaster(parameters);
                                                    }else{
                                                        response =  consultarDefaultIntentFallback();
                                                    }
                                                }
                                            }  
                                        }
                                    }
                                }
                            }
                        }
                    }
                }    
            }
        }       
        return response;  
    }

    private String consultarContenidoMaster(Map<String,String> parameters){
          String programa = parameters.get("Master");
          String response;
        if(null==programa||programa.equals("")){
            response = consultarDefaultMissingMasterInfo();
        }else{
            response = controlConsultarMaster.getDescripcionMaster(programa);
        }
        if(response==null){
                response = consultarDefaultServiceNotAvailable();
        }
        return response;
    }    
    
    
    /**
     * Metodo consultarDisponibilidadMasteres, consulta el listado de masteres disponibles.
     * 
     * @return String con la respuesta de masteres disponibles
     */
    private String consultarDisponibilidadMasteres() {
        List<String> response = controlListadoMaster.getListadoMasteres();     
        StringBuilder bld = new StringBuilder();
  
   
        String resp = "";
        if(response==null){
           resp = consultarDefaultServiceNotAvailable();
        }else{
           
           for(int i=0;i<response.size();i++){
               bld.append(response.get(i)).append("\n");
           }
           resp = bld.toString();
        }
        
        return resp;
    }

    /**
     * Metodo consultarAccesoMasteres, consulta las condiciones de acceso a un master.
     * 
     * @param parameters los parametros necesarios para iniciar el cu
     * @return String con la respuesta de aceptacion o denegacion de acceso
     */
    private String consultarAccesoMasteres(Map<String,String> parameters) {
        String programa = parameters.get("Master");
        String nacionalidad = null;
        Boolean posesionTitulo = null;
        String response = null;
        if(null==programa||programa.equals("")){
             response=consultarDefaultMissingMasterInfo();
        }else{
            if(parameters.containsKey("geo-country")){
                nacionalidad = parameters.get("geo-country");
                if(nacionalidad.equals("")){
                    nacionalidad=null;
                }
            }

            if(parameters.containsKey("AfirmacionNegacion")){
                 if(parameters.get("AfirmacionNegacion").equals("si")){
                     posesionTitulo=true;
                 }else{
                     posesionTitulo=false;
                 }
            }


            response = controlConsultarAccesoMaster.tratarDialogoAccesoMaster(programa,nacionalidad,posesionTitulo);     
             
            if(response==null){
                response = consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
         
    }
    
    /**
     * Método consultarNivelIdiomasMaster, consulta los idiomas de imparticion de un master.
     * 
     * @param parameters los parametros para iniciar el cu
     * @return String con la respuesta de idiomas de imparticion
     */
    private String consultarNivelIdiomasMaster(Map<String,String> parameters) {
        String programa = parameters.get("Master");
        String idioma = null;
        
        String response = null;
        
        if(null==programa||programa.equals("")){
            
            response=consultarDefaultMissingMasterInfo();
       
        }else{
            
            if(parameters.containsKey("language")){
                idioma = parameters.get("language");
                if(idioma.equals("")){
                    idioma = null;
                }
            }
            if(idioma==null){
                 
                response = controlConsultarIdiomasMaster.consultarIdiomasMaster(programa);
            }else{
                response = controlConsultarIdiomasMaster.consultarIdiomasMaster(programa,idioma);     
            }
            if(response==null){
                response = consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    
    }
    
    /**
     * Metodo consultarPrecioAproximadoMaster, da una estimacion del precio del master para el procimo año.
     * 
     * @param parameters los parametros para iniciar el cu
     * @return String con la respuesta de precio aproximado
     */
    private String consultarPrecioAproximadoMaster(Map<String, String> parameters) {
        String programa = parameters.get("Master");
        String response=null;
        
        if(null==programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response =  controlConsultarPrecioMaster.consultarPrecioMaster(programa);     
            if(response==null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    }
    
    /**
     * Metodo consultarPresencialidadMaster, consulta la presencialidad necesaria para cursar el master.
     * 
     * @param parameters parametros para iniciar el cu
     * @return String con la respuesta de presencialidad de imparticion
     */
    private String consultarPresencialidadMaster(Map<String, String> parameters) {
        String programa = parameters.get("Master");
        String response=null;
        
        if(null==programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response =  controlPresencialidadMaster.consultarPresencialidadMaster(programa);     
            if(response==null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
        
    }
    
    /**
     * Metodo consultarCronogramaMaster, consulta el cronograma de imparticion del master.
     * 
     * @param parameters los parametros para iniciar el cu
     * @return String con la respuesta de cronograma de imparticion 
     */
    private String consultarCronogramaMaster(Map<String, String> parameters) {
       
        String programa = parameters.get("Master");
        String response = null;
        
        if(null == programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response =  controlCronogramaMaster.consultaCronogramaMaster(programa);     
            if(response == null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    }

    /**
     * Metodo consultarLProgMaster, consulta la necesidad de lenguajes de programacion
     * para cursar un master.
     * 
     * @param parameters los parametros para iniciar el cu
     * @return String con la respuesta de lenguajes de programacion de imparticion 
     */
    private String consultarLProgMaster(Map<String, String> parameters) {
          
        String programa = parameters.get("Master");
        String response = null;
        
        if(null == programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response=controlConsultarLenguajesProgramacion.consultarRecomendacionLenguajes(programa);     
            if(response == null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    }
    /**
     * Metodo consultarECTS, consulta que es un credito ECTS.
     * 
     * @return String
     */
    private String consultarECTS() {
        String response = controlConsultarECTS.consultarECTS();
        if(response == null){
            response=consultarDefaultServiceNotAvailable();
        } 
        return response;
    }
    /**
     * Metodo consultarColaboracionesMaster, consulta las colaboracioens asociadas a un master.
     * 
     * @param parameters los parametros para iniciar el cu
     * @return String con la respuesta de lenguajes de programacion de imparticion  
     */
     private String consultarColaboracionesMaster(Map<String, String> parameters) {
        String programa = parameters.get("Master");
        String response = null;
        
        if(null == programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response=controlColaboracionesMaster.consultarColaboracionesMaster(programa);     
            if(response == null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    }
    /**
     * Metodo consultarInformacionConvalidaciones, consulta la inforamcion de convalidacion
     * de asignaturas.
     * 
     * @return String
     */ 
    private String consultarInformacionConvalidaciones() {
         
        String response =  controlConsultarConvalidacion.consultarProcesoConvalidacion();     
        if(response == null){
            response=consultarDefaultServiceNotAvailable();
        } 
        
        return response;
    }
    
     private String consultarCorreoMaster(Map<String, String> parameters) {
        String programa = parameters.get("Master");
        String response = null;
        
        if(null == programa||programa.equals("")){
            response=consultarDefaultMissingMasterInfo();
        }else{
            response=controlConsultarCorreoCoordinacion.consultarCorreoCoordinacionMaster(programa);     
            if(response == null){
                response=consultarDefaultServiceNotAvailable();
            } 
        }
        return response;
    }

    private String consultarDefaultIntentFallback() {
       return modeloDefaultFallback.getDefaultIntentFallbackResponse();
    }
    
    private String consultarDefaultServiceNotAvailable(){
       return modeloDefaultFallback.getDefaultServiceNotAvailable();
    }
    
    private String consultarDefaultMissingMasterInfo(){
        return modeloDefaultFallback.getDefaultMissingMasterInfo();
    }
    
    public ModeloDefaultFallback getModeloDefaultFallback() {
        return modeloDefaultFallback;
    }

    public void setModeloDefaultFallback(ModeloDefaultFallback modeloDefaultFallback) {
        this.modeloDefaultFallback = modeloDefaultFallback;
    }

    public void setControlInformarMaster(CULogicaInformarPlanesMaster controlInformarMaster) {
        this.controlListadoMaster = controlInformarMaster;
    }

    public void setControlConsultarAccesoMaster(CULogicaConsultarAccesoMaster controlConsultarAccesoMaster) {
        this.controlConsultarAccesoMaster = controlConsultarAccesoMaster;
    }

    public void setControlConsultarIdiomasMaster(CULogicaConsultarIdiomasMaster controlConsultarIdiomasMaster) {
        this.controlConsultarIdiomasMaster = controlConsultarIdiomasMaster;
    }

    public void setControlConsultarPrecioMaster(CULogicaConsultarPrecioAproximadoMaster controlConsultarPrecioMaster) {
        this.controlConsultarPrecioMaster = controlConsultarPrecioMaster;
    }

    public void setControlPresencialidadMaster(CULogicaConsultarPresencialidadMaster controlPresencialidadMaster) {
        this.controlPresencialidadMaster = controlPresencialidadMaster;
    }

    public CULogicaInformarPlanesMaster getControlListadoMaster() {
        return controlListadoMaster;
    }

    public void setControlListadoMaster(CULogicaInformarPlanesMaster controlListadoMaster) {
        this.controlListadoMaster = controlListadoMaster;
    }

    public CULogicaConsultarCronogramaMaster getControlCronogramaMaster() {
        return controlCronogramaMaster;
    }

    public void setControlCronogramaMaster(CULogicaConsultarCronogramaMaster controlCronogramaMaster) {
        this.controlCronogramaMaster = controlCronogramaMaster;
    }

    public CULogicaConsultarContenidoMaster getControlConsultarMaster() {
        return controlConsultarMaster;
    }

    public void setControlConsultarMaster(CULogicaConsultarContenidoMaster controlConsultarMaster) {
        this.controlConsultarMaster = controlConsultarMaster;
    }

    public CULogicaConsultarLenguajesProgramacion getControlConsultarLenguajesProgramacion() {
        return controlConsultarLenguajesProgramacion;
    }

    public void setControlConsultarLenguajesProgramacion(CULogicaConsultarLenguajesProgramacion controlConsultarLenguajesProgramacion) {
        this.controlConsultarLenguajesProgramacion = controlConsultarLenguajesProgramacion;
    }

    public CULogicaConsultarECTS getControlConsultarECTS() {
        return controlConsultarECTS;
    }

    public void setControlConsultarECTS(CULogicaConsultarECTS controlConsultarECTS) {
        this.controlConsultarECTS = controlConsultarECTS;
    }

    public CULogicaConsultarColaboracionesMaster getControlColaboracionesMaster() {
        return controlColaboracionesMaster;
    }

    public void setControlColaboracionesMaster(CULogicaConsultarColaboracionesMaster controlColaboracionesMaster) {
        this.controlColaboracionesMaster = controlColaboracionesMaster;
    }

   

    

   
    
}