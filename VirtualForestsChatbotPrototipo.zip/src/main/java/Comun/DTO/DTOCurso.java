/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comun.DTO;

/**
 *
 * @author usuario
 */
public class DTOCurso {
    private int numeroCurso;
    private int numMesInicio;
    private int numMesFin;
    private String mesInicio;
    private String mesFin;
    private int numeroECTS;
    private String master;

    public DTOCurso(int numeroCurso, int numMesInicio, int numMesFin, String mesInicio, String mesFin, int numeroECTS, String master) {
        this.numeroCurso = numeroCurso;
        this.numMesInicio = numMesInicio;
        this.numMesFin = numMesFin;
        this.mesInicio = mesInicio;
        this.mesFin = mesFin;
        this.numeroECTS = numeroECTS;
        this.master = master;
    }
    
    
    public DTOCurso(int numeroCurso, int numMesInicio, int numMesFin, int numeroECTS, String master) {
        this.numeroCurso = numeroCurso;
        this.numMesInicio = numMesInicio;
        this.numMesFin = numMesFin;
        this.numeroECTS = numeroECTS;
        this.master = master;
    }

    public int getNumeroCurso() {
        return numeroCurso;
    }

    public void setNumeroCurso(int numeroCurso) {
        this.numeroCurso = numeroCurso;
    }

    public int getNumMesInicio() {
        return numMesInicio;
    }

    public void setNumMesInicio(int numMesInicio) {
        this.numMesInicio = numMesInicio;
    }

    public int getNumMesFin() {
        return numMesFin;
    }

    public void setNumMesFin(int numMesFin) {
        this.numMesFin = numMesFin;
    }

    public String getMesInicio() {
        return mesInicio;
    }

    public void setMesInicio(String mesInicio) {
        this.mesInicio = mesInicio;
    }

    public String getMesFin() {
        return mesFin;
    }

    public void setMesFin(String mesFin) {
        this.mesFin = mesFin;
    }

    public int getNumeroECTS() {
        return numeroECTS;
    }

    public void setNumeroECTS(int numeroECTS) {
        this.numeroECTS = numeroECTS;
    }

    public String getMaster() {
        return master;
    }

    public void setMaster(String master) {
        this.master = master;
    }
    
    
    
    
}
