/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comun.DTO;

import java.io.Serializable;

/**
 * Clase DTOColaboracion, implementa el DTO para entidades Colaboracion.
 * 
 * @author JAA
 */
public class DTOColaboracion implements Serializable { 
    private String entidad;
    private String pais;
    private String descripcion;
    
    public DTOColaboracion(String entidad, String pais, String descripcion){
        this.entidad = entidad;
        this.pais = pais;
        this.descripcion = descripcion;
    } 

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
