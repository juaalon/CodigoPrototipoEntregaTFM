/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Comun.DTO;
import java.io.Serializable;
/**
 * DTO de la informacion de un Master.
 * 
 * @author JAA
 */
public class DTOMaster implements Serializable {
    private int id;
    private int codigoPlan;
    private String nombre;
    private String descripcion;
    private int precioAproximado;
    private String presencialidad;
    private boolean dobleTitulacion;
    private boolean gHomologado;
    private String grado;
    private String idiomaPrincipal;
    private String idiomaSecundario;
    private String lProgPrincipal;
    private String lProgSecundario;
    private String cCoordinacion;

    public DTOMaster(int id, int codigoPlan, String nombre, String descripcion, int precioAproximado, String presencialidad, boolean dobleTitulacion, boolean gHomologado, String grado, String idiomaPrincipal, String idiomaSecundario, String lProgPrincipal, String lProgSecundario, String cCoordinacion) {
        this.id = id;
        this.codigoPlan = codigoPlan;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precioAproximado = precioAproximado;
        this.presencialidad = presencialidad;
        this.dobleTitulacion = dobleTitulacion;
        this.gHomologado = gHomologado;
        this.grado = grado;
        this.idiomaPrincipal = idiomaPrincipal;
        this.idiomaSecundario = idiomaSecundario;
        this.lProgPrincipal = lProgPrincipal;
        this.lProgSecundario = lProgSecundario;
        this.cCoordinacion = cCoordinacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodigoPlan() {
        return codigoPlan;
    }

    public void setCodigoPlan(int codigoPlan) {
        this.codigoPlan = codigoPlan;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecioAproximado() {
        return precioAproximado;
    }

    public void setPrecioAproximado(int precioAproximado) {
        this.precioAproximado = precioAproximado;
    }

    public String getPresencialidad() {
        return presencialidad;
    }

    public void setPresencialidad(String presencialidad) {
        this.presencialidad = presencialidad;
    }

    public boolean isDobleTitulacion() {
        return dobleTitulacion;
    }

    public void setDobleTitulacion(boolean dobleTitulacion) {
        this.dobleTitulacion = dobleTitulacion;
    }

    public boolean isgHomologado() {
        return gHomologado;
    }

    public void setgHomologado(boolean gHomologado) {
        this.gHomologado = gHomologado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getIdiomaPrincipal() {
        return idiomaPrincipal;
    }

    public void setIdiomaPrincipal(String idiomaPrincipal) {
        this.idiomaPrincipal = idiomaPrincipal;
    }

    public String getIdiomaSecundario() {
        return idiomaSecundario;
    }

    public void setIdiomaSecundario(String idiomaSecundario) {
        this.idiomaSecundario = idiomaSecundario;
    }

    public String getlProgPrincipal() {
        return lProgPrincipal;
    }

    public void setlProgPrincipal(String lProgPrincipal) {
        this.lProgPrincipal = lProgPrincipal;
    }

    public String getlProgSecundario() {
        return lProgSecundario;
    }

    public void setlProgSecundario(String lProgSecundario) {
        this.lProgSecundario = lProgSecundario;
    }

    public String getcCoordinacion() {
        return cCoordinacion;
    }

    public void setcCoordinacion(String cCoordinacion) {
        this.cCoordinacion = cCoordinacion;
    }
 
 
     
    
    
}
