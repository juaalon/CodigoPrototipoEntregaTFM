/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarAccesoMaster;

import Comun.DTO.DTOColaboracion;
import Comun.DTO.DTOMaster;
import Persistencia.CUFachadaConsultarAccesoMaster;
import Persistencia.FachadaBD;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase CUConsultarAccesoMasterM
 * 
 * @author JAA
 */
public class CUConsultarAccesoMasterM implements CUModeloConsultarAccesoMaster{
    private CUFachadaConsultarAccesoMaster fachada;
    
    public CUConsultarAccesoMasterM(){
        fachada = FachadaBD.getInstancia();
    }
    
     public CUConsultarAccesoMasterM(CUFachadaConsultarAccesoMaster f){
        fachada = f;
    }
    
     
    /**
     * Metodo getRespuestaSolicitudPais, obtiene la respuesta de requisitos de acceso a un master
     * en base al país de la entidad que expedió el título que le da acceso al máster.
     * 
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaSolicitudPais() {
        return fachada.getRespuestaSolicitudPaisAccesoMaster();
         
    }
     
    
    /**
     * Metodo getNecesidadHomologacion, obtiene la respuesta de requisitos de acceso a un master
     * de si requiere un graduado homologable.
     * 
     * @param programa Un string con el programa del master
     * @return  Noolean con la respuesta
     */
    @Override
    public Boolean getNecesidadHomologacion(String programa) {
        return consultaHomologacionMaster(programa);         
    }   
    
    /**
     * Metodo getRespuestaTituloNecesarioHomologar, obtiene la respuesta de requisitos de acceso al Master
     * sobre la necesidad de posesion de un titulo de graduado homologado .
     * 
     * @param titulo Un String con el titulo del master
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaTituloNecesarioHomologar(String titulo) {
         String grado = fachada.getGraduadoNecesarioHomologar(titulo);
         String pregunta = fachada.getSolicitudGradoHomologado();
         if(pregunta!=null&&grado!=null){
            return pregunta.replace("<stub>", grado);
         }else{
            return null;
         }
    }
    
    /**
     * Metodo getRespuestaTituloUniversitario, obtiene la respuesta de requisitos de acceso al Master
     * sobre la necesidad de posesion de un titulo de graduado homologado .
     * 
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaTituloUniversitario() {
        //return "¿Tienes un grado universitario que te permita acceder a un programa de maśter?\n";
          
         String pregunta = fachada.getPreguntaGrado();
         if(pregunta!=null ){
            return pregunta ;
         }else{
            return null;
         }
    }
    
    /**
     * Metodo getRespuestaPosesionGraduado, obtiene la respuesta de requisitos de acceso al Master
     * sobre la necesidad de posesion de un titulo de graduado expedido por entidad española .
     * 
     * @param programa Un String con el programa de master
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaPosesionGraduado(String programa) {
        String tituloRequerido = fachada.getGraduadoNecesarioAccesoProgramaMaster(programa);
        String pregunta = fachada.getPreguntaGradoEspecifico();
        if(pregunta!=null){
            if(tituloRequerido!=null){
                return pregunta.replace("<stub>", tituloRequerido);
            }else{
                return fachada.getPreguntaGrado();
            }
        }else{
            return null;
        }
    }
    
    /**
     * Metodo getRequisitoHomologacionAccesoMaster, obtiene la respuesta de requisitos de acceso a un master
     * de si requiere un graduado homologable.
     * 
     * @param programa el programa de master
     * @return  boolean con la respuesta
     */
    @Override
    public Boolean getRequisitoHomologacionAccesoMaster(String programa) {
        return consultaHomologacionMaster(programa);
    }
    
    
    /**
     * Metodo consultaHomologacionMaster, consulta la condiccion de homologacion de un titulo de grado
     * previo a la inscripcion en el master.
     * 
     * @param programa String con el programa de master a acceder
     * @return Boolean con la respuesta
     */
    private Boolean consultaHomologacionMaster(String programa){
        Boolean requisitoHomologacion = fachada.getNecesidadHomologacionMaster(programa);        
        if(requisitoHomologacion==null){
            return null;
        }else{
            return requisitoHomologacion;
        }
    }

    /**
     * Metodo getRespuestaSolicitudTituloCompatibleHomologado recupera la respuesta
     * para plantear al usuario de si posee el titulo de grado que permite acceso al master y esta
     * homologado.
     * 
     * @param programa String con el programa de master a consultar
     * @return String con la respuesta de peticion de titulo solicitada
     */
    @Override
    public String getRespuestaSolicitudTituloCompatibleHomologado(String programa) {
        String tituloRequerido = fachada.getGraduadoNecesarioAccesoProgramaMaster(programa);
        String pregunta = fachada.getPreguntaGraduadoEspecificoHomologado();
        if(tituloRequerido!=null&&pregunta!=null){
             return pregunta.replace("<stub>", tituloRequerido);
        }else{
            return null;
        }
    }
/**
     * Metodo getRespuestaPosesionGraduadoUniversitario recupera la respuesta
     * de si el usuario requiere un grado universitario para el acceso al master
     * 
     * @return String con la respuesta de peticion de titulo solicitada
     */
    @Override
    public String getRespuestaPosesionGraduadoUniversitario() {
        return fachada.getPreguntaGrado();
    }

    
    /**
     * Metodo getColaboracionesMaster, recupera las colaboraciones de entidades externas
     * asociadas al programa de master.
     * 
     * @param programa String con el programa de amster
     * @return List<String> con el listado de opciones
     */
    @Override
    public List<DTOColaboracion> getColaboracionesMaster(String programa) {
        List<DTOColaboracion> listado = fachada.getColaboracionesMaster(programa);
        return listado;
    }
    
    /**
     * Metodo getRespuestaAccesoMaster, proporciona la respuesta al usuario de 
     * acceso al master indicado.
     * 
     * 
     * @param programa String con el programa de master al que conceder acceso
     * @return  String con la respuesta de acceso al master
     */
    @Override
    public String getRespuestaAccesoMaster(String programa) {
        
        return fachada.getRespuestaAceptacionMaster().replace("<stub>",programa);
    }

    /**
     * Metodo getProgramasAlternativos, proporciona un listado de masteres que no requieren
     * un graduado especifico para su acceso.
     * 
     * 
     * @return Un listado con los nombres de los programas de master
     */
    @Override
    public List<String> getProgramasAlternativos() {
        List<DTOMaster> listado = fachada.getListadoMasteresAlternativos();
        ArrayList<String> list = new ArrayList();
        if(listado!=null){
            for(int i=0;i<listado.size();i++){
                list.add(listado.get(i).getNombre());
            }
        }
        return list;
    }
    
    /**
     * Metodo getRespuestaNoAccesoMaster, proporciona una respuesta negativa para indicar
     * que no esposible el acceso al master.
     * 
     * 
     * @return Un String con la respuesta
     */
    @Override
    public String getRespuestaNoAccesoMaster(String programa) {
        return fachada.getRespuestaNoAceptacionMaster().replace("<stub>",programa);
    }

    /**
     * Metodo getRespuestaAccesoMasterNoHomologado, da la respuesta al intentar acceder
     * a un programa de master sin el título homologado requerido.
     * 
     * @param programa  Programa de master
     * @return String con la respuesta
     */
    @Override
    public String getRespuestaAccesoMasterNoHomologado(String programa){
        String respuesta = fachada.getRespuestaNoAceptacionMaster().replace("<stub>",programa);
        respuesta = respuesta +"\n"+ fachada.getRespuestaObligacionHomologacion().replace("<stub>",programa);
        return respuesta;
    }

    @Override
    public String getRespuestaPresentacionColaboraciones() {
        return fachada.getPresentacionColaboracionesAparte();
    }
     

    
}
