/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Persistencia.FachadaBD;

/**
 *
 * @author JAA
 */
public class ModeloDefaultFallback {

    private FachadaBD fachada;
    
    public ModeloDefaultFallback(){
        fachada = FachadaBD.getInstancia();
    }
    public ModeloDefaultFallback(FachadaBD f){
        fachada = f;
    }
    
    public String getDefaultIntentFallbackResponse() {
         return fachada.getDefaultInteractionIntentFallback();
    }

    public String getDefaultServiceNotAvailable() {
         return fachada.getDefaultInteractionServiceNotAvailable();
    }
    
    public String getDefaultMissingMasterInfo(){
        return fachada.getDefaultInteractionMissingMasterInfo();
    }
    
}
