/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarCorreoCoordinadorMaster;

import Persistencia.CUFachadaConsultarCorreoCoordinadorMaster;
import Persistencia.FachadaBD;

/**
 *
 * @author usuario
 */
public class CUConsultarCorreoCoordinadorMasterM implements CUModeloConsultarCorreoCoordinadorMaster{
    private CUFachadaConsultarCorreoCoordinadorMaster fachada;
    
    public CUConsultarCorreoCoordinadorMasterM(){
        fachada = FachadaBD.getInstancia();
    }
    
    @Override
    public String consultarCorreoCoordinacionMaster(String programa) {
        return fachada.getContactoCoordinacion(programa);
    }

    @Override
    public String getPresentacionCoordinacion() {
        return fachada.getPresentacionCoordinacion();
    }
    
}
