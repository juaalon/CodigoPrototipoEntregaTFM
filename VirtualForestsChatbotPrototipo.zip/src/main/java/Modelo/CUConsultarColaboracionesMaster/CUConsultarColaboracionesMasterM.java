/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarColaboracionesMaster;

import Comun.DTO.DTOColaboracion;
import Persistencia.CUFachadaConsultarColaboraciones;
import Persistencia.FachadaBD;
import java.util.List;

/**
 * Clase CUConsultarColaboracionesMasterM, implementa el modelo del CU Consultar Colaboraciones Master.
 * 
 * @author JAA
 */
public class CUConsultarColaboracionesMasterM implements CUModeloConsultarColaboracionesMaster{

    private CUFachadaConsultarColaboraciones fachada;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarColaboracionesMasterM(){
        fachada = FachadaBD.getInstancia();
    }
    
    public CUConsultarColaboracionesMasterM(CUFachadaConsultarColaboraciones f){
        fachada = f;
    }
    
    @Override
    public List<DTOColaboracion> getColaboraciones(String programa) {
         return fachada.getColaboracionesMaster(programa);
    }

    @Override
    public String getPresentacionColaboraciones() {
        return fachada.getPresentacionColaboraciones();
    }

    @Override
    public String getPlantillaColaboracion() {
        return fachada.getPlantillaColaboracion();
    }

    @Override
    public String getMensajeColaboracionesNulas() {
        return fachada.getMensajeNoHayColaboraciones();
    }
    
}
