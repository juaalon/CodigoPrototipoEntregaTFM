/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarPrecioAproximadoMaster;

/**
 *
 * @author usuario
 */
public interface CUModeloConsultarPrecioAproximadoMaster {

    public String getPresentacionPrecioAproximado();

    public int consultarprecioAproximado(String programa);
    
}
