/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarPrecioAproximadoMaster;

import Persistencia.CUFachadaConsultarPrecioAproximadoMaster;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarPrecioAproximadoMasterM, impleenta el modelo del CU Consultar Precio Aproximado Master.
 * 
 * @author JAA
 */
public class CUConsultarPrecioAproximadoMasterM implements CUModeloConsultarPrecioAproximadoMaster{

    private CUFachadaConsultarPrecioAproximadoMaster fachada;
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarPrecioAproximadoMasterM(){
        fachada = FachadaBD.getInstancia();
        
    }
    
    public CUConsultarPrecioAproximadoMasterM(CUFachadaConsultarPrecioAproximadoMaster f){
        fachada = f;
        
    }
    /**
     * Metodo getPresentacionPrecioAproximado, obtiene la frase de presentacion de 
     * precio aproximado del master.
     * 
     * @return String con la frase
     */
    @Override
    public String getPresentacionPrecioAproximado() {
       return fachada.getPresentacionPrecioMaster();
    }

    /**
     * Metodo consultarprecioAproximado, obtiene el precio aproximado del master
     * para el proximo año.
     * 
     * @param programa String con el programa de master
     * @return int con una aproximacion del precio
     */
    @Override
    public int consultarprecioAproximado(String programa) {
       return fachada.getPrecioMaster(programa);
    }
    
}
