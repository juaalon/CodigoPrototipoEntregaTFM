/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.CUConsultarECTS;

import Persistencia.CUFachadaConsultarECTS;
import Persistencia.FachadaBD;

/**
 * Clase CUConsultarECTSM, implementa el modelo del CU  Consultar ECTS.
 * 
 * @author JAA
 */
public class CUConsultarECTSM implements CUModeloConsultarECTS {
    
    private CUFachadaConsultarECTS fachada;
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarECTSM(){
     fachada = FachadaBD.getInstancia();
    }
    
    public CUConsultarECTSM(CUFachadaConsultarECTS f){
     fachada = f;
    }
    /**
     * Metodo getInfoECTS, devuelve la informacion de creditos ECTS.
     * 
     * @return String con la info
     */
    @Override
    public String getInfoECTS() {
        return fachada.getDescripcionECTS();
    }
    
}
