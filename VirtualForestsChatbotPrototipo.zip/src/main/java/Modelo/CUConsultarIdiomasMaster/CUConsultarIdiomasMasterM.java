
package Modelo.CUConsultarIdiomasMaster;

import Comun.DTO.DTOIdioma;
import Persistencia.CUFachadaConsultarIdiomasMaster;
import Persistencia.FachadaBD;
import java.util.List;

/**
 * Clase CUConsultarIdiomasMasterM, implementa el modelo del CU Consultar idiomas Master.
 * 
 * @author JAA
 */
public class CUConsultarIdiomasMasterM implements CUModeloConsultarIdiomasMaster {

    private CUFachadaConsultarIdiomasMaster fachada;
    
    /**
     * Constructor de clase.
     * 
     */
    public CUConsultarIdiomasMasterM(){
        fachada = FachadaBD.getInstancia();
    
    }
    
    public CUConsultarIdiomasMasterM(CUFachadaConsultarIdiomasMaster fachada){
        this.fachada=fachada;
    
    }
    
    /**
     * Metodo getRespuestaIdiomasyNivelesMaster, devuelve la respuesta a los idiomas
     * de imparticion de un máster. 
     * 
     * @param programa String con el programa de master
     * @return  List<DTOIdioma> con el listado de idiomas
     */
    @Override
    public List<DTOIdioma> getRespuestaIdiomasyNivelesMaster(String programa) {
         return fachada.getIdiomasDeMaster(programa);
          
    }

    /**
     * Metodo getRespuestaIdiomaEspecificoyNivelesMaster, devuelve la respuesta a los idiomas
     * de imparticion de un máster. 
     * 
     * @param programa String con el programa de master
     * @param idioma String con el idioma a buscar
     * @return  List<DTOIdioma> con el listado de idiomas
     */
    @Override
    public List<DTOIdioma> getRespuestaIdiomaEspecificoyNivelesMaster(String programa, String idioma) {
         List<DTOIdioma> idiomas = fachada.getIdiomasDeMaster(programa,idioma);
         return idiomas;
    }

    /**
     * Metodo getRespuestaIdiomasEncontrados, devuelve la respuesta a que se ha 
     * encontrado los idiomas asociados a un máster. 
     * 
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaIdiomasEncontrados() {
        return fachada.getRespuestaIdiomasEncontrados();
    }
    
    /**
     * Metodo getRespuestaIdiomasNoEncontrados, devuelve la respuesta a que no se ha 
     * encontrado los idiomas asociados a un máster. 
     * 
     * @return  String con la respuesta
     */
    @Override
    public String getRespuestaIdiomasNoEncontrados() {
        return fachada.getRespuestaIdiomasNoEncontrados();
    }

    /**
     * Metodo getPlantillaIdioma, devuelve la respuesta a la plantilla a rellenar
     * con los idiomas encontrados.
     * 
     * @return  String con la respuesta
     */
    @Override
    public String getPlantillaIdioma() {
       return fachada.getPlantillaIdioma();
    }
    
}
