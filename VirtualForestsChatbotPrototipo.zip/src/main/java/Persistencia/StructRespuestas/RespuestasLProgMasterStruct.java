/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 * Clase RespuestasLProgMasterStruct
 * 
 * @author JAA
 */
public class RespuestasLProgMasterStruct {
    private String presentacionLProg;
    private String plantillaLProg;
    private String noHayLenguajes;

    public RespuestasLProgMasterStruct(String presentacionLProg, String plantillaLProg, String noHayLenguajes) {
        this.presentacionLProg = presentacionLProg;
        this.plantillaLProg = plantillaLProg;
        this.noHayLenguajes = noHayLenguajes;
    }

    public String getPresentacionLProg() {
        return presentacionLProg;
    }

    public void setPresentacionLProg(String presentacionLProg) {
        this.presentacionLProg = presentacionLProg;
    }

    public String getPlantillaLProg() {
        return plantillaLProg;
    }

    public void setPlantillaLProg(String plantillaLProg) {
        this.plantillaLProg = plantillaLProg;
    }

    public String getNoHayLenguajes() {
        return noHayLenguajes;
    }

    public void setNoHayLenguajes(String noHayLenguajes) {
        this.noHayLenguajes = noHayLenguajes;
    }

    
}
