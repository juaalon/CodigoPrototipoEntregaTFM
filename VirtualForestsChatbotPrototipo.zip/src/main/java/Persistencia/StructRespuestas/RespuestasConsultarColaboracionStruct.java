/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 *
 * @author JAA
 */
public class RespuestasConsultarColaboracionStruct {
    private String plantillaPresentacion;
    private String noHayColaboracion;
    private String plantillaColaboracion;
    private String presentacionAparte;

    public RespuestasConsultarColaboracionStruct(String plantillaPresentacion, String noHayColaboracion, String plantillaColaboracion, String presentacionAparte) {
        this.plantillaPresentacion = plantillaPresentacion;
        this.noHayColaboracion = noHayColaboracion;
        this.plantillaColaboracion = plantillaColaboracion;
        this.presentacionAparte = presentacionAparte;
    }

    public String getPlantillaPresentacion() {
        return plantillaPresentacion;
    }

    public void setPlantillaPresentacion(String plantillaPresentacion) {
        this.plantillaPresentacion = plantillaPresentacion;
    }

    public String getNoHayColaboracion() {
        return noHayColaboracion;
    }

    public void setNoHayColaboracion(String noHayColaboracion) {
        this.noHayColaboracion = noHayColaboracion;
    }

    public String getPlantillaColaboracion() {
        return plantillaColaboracion;
    }

    public void setPlantillaColaboracion(String plantillaColaboracion) {
        this.plantillaColaboracion = plantillaColaboracion;
    }

    public String getPresentacionAparte() {
        return presentacionAparte;
    }

    public void setPresentacionAparte(String presentacionAparte) {
        this.presentacionAparte = presentacionAparte;
    }
 
    
}
