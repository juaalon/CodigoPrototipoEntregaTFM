
package Persistencia.StructRespuestas;

/**
 *
 * @author JAA
 */
public class RespuestasPresencialidadMasterStruct {

    private String presentacionPresencialidad;
    private String excepcionalidadPresencialidad;

    public RespuestasPresencialidadMasterStruct(String presentacionPresencialidad, String excepcionalidadPresencialidad) {
        this.presentacionPresencialidad = presentacionPresencialidad;
        this.excepcionalidadPresencialidad = excepcionalidadPresencialidad;
    }

    public String getPresentacionPresencialidad() {
        return presentacionPresencialidad;
    }

    public void setPresentacionPresencialidad(String presentacionPresencialidad) {
        this.presentacionPresencialidad = presentacionPresencialidad;
    }

    public String getExcepcionalidadPresencialidad() {
        return excepcionalidadPresencialidad;
    }

    public void setExcepcionalidadPresencialidad(String excepcionalidadPresencialidad) {
        this.excepcionalidadPresencialidad = excepcionalidadPresencialidad;
    }
    
    
    
}