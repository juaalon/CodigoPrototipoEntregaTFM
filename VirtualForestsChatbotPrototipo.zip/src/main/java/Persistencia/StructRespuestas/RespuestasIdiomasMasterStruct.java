/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.StructRespuestas;

/**
 * Clase RespuestasIdiomasMasterStruct, parseado de las respuestas de idiomas del master
 * 
 * @author JAA
 */
public class RespuestasIdiomasMasterStruct {
    private String queryIdiomas;
    private String queryNoIdiomas;
    private String plantillaIdioma;

    public RespuestasIdiomasMasterStruct(String queryIdiomas, String queryNoIdiomas, String plantillaIdioma) {
        this.queryIdiomas = queryIdiomas;
        this.queryNoIdiomas = queryNoIdiomas;
        this.plantillaIdioma = plantillaIdioma;
    }

    public String getQueryIdiomas() {
        return queryIdiomas;
    }

    public void setQueryIdiomas(String queryIdiomas) {
        this.queryIdiomas = queryIdiomas;
    }

    public String getQueryNoIdiomas() {
        return queryNoIdiomas;
    }

    public void setQueryNoIdiomas(String queryNoIdiomas) {
        this.queryNoIdiomas = queryNoIdiomas;
    }

    public String getPlantillaIdioma() {
        return plantillaIdioma;
    }

    public void setPlantillaIdioma(String plantillaIdioma) {
        this.plantillaIdioma = plantillaIdioma;
    }
    
    
}
