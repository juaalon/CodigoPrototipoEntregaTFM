 
package Persistencia;

import Comun.DTO.DTOColaboracion;
import Comun.DTO.DTOMaster;
import java.util.List;


/**
 * Interfaz con la fachada de Persistencia del CU Consultar Acceso Master
 * 
 * @author JAA
 */
public interface CUFachadaConsultarAccesoMaster {

    public Boolean getNecesidadHomologacionMaster(String programa);

    public String getGraduadoNecesarioHomologar(String titulo);

    public String getGraduadoNecesarioAccesoProgramaMaster(String programa);

    public List<DTOColaboracion> getColaboracionesMaster(String programa);

    public String getRespuestaSolicitudPaisAccesoMaster();

    public String getSolicitudGradoHomologado();

    public String getPreguntaGrado();

    public String getPreguntaGradoEspecifico();

    public String getPreguntaGraduadoEspecificoHomologado();

    public String getRespuestaAceptacionMaster();

    public List<DTOMaster> getListadoMasteresAlternativos();

    public String getRespuestaNoAceptacionMaster();

    public String getRespuestaObligacionHomologacion();
 
    public String getPresentacionColaboracionesAparte();
 
    
}
