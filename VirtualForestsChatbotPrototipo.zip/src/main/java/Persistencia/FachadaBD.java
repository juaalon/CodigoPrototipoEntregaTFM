/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Persistencia.DAO.ConvalidacionDAOInterface;
import Comun.DTO.DTOColaboracion;
import Comun.DTO.DTOCurso;
import Comun.DTO.DTOIdioma;
import Comun.DTO.DTOMaster;
import Persistencia.DAO.ColaboracionDAO;
import Persistencia.DAO.ColaboracionDAOInterface;
import Persistencia.DAO.CommonDAO;
import Persistencia.DAO.CommonDAOInterface;
import Persistencia.DAO.ConvalidacionDAO;
import Persistencia.DAO.CursoDAO;
import Persistencia.DAO.CursoDAOInterface;
import Persistencia.DAO.ECTSDAO;
import Persistencia.DAO.ECTSDAOInterface;
import Persistencia.DAO.IdiomaDAO;
import Persistencia.DAO.IdiomaDAOInterface;
import Persistencia.DAO.MasterDAO;
import Persistencia.DAO.MasterDAOInterface;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase FachadaBD, implementa la fachada de acceso a rpos de datos por parte del dominio 
 * de la aplicacion.
 * 
 * @author JAA
 */
public class FachadaBD implements CUFachadaInformarPlanesMaster,CUFachadaConsultarAccesoMaster,
        CUFachadaConsultarIdiomasMaster,CUFachadaConsultarPrecioAproximadoMaster,
        CUFachadaConsultarPresencialidadMaster,CUFachadaConsultarCronogramaMaster,
        CUFachadaConsultarContenidoMaster,CUFachadaConsultarLenguajesProgramacion,
        CUFachadaConsultarECTS,CUFachadaConsultarColaboraciones,
        CUFachadaConsultarInformacionConvalidacion,
        CUFachadaConsultarCorreoCoordinadorMaster{
    
    private static ConnectionPool pool;
    private static Connection conn;
    private static FachadaBD instancia;
    private  MasterDAOInterface master;
    private  ColaboracionDAOInterface colaboracion;
    private  IdiomaDAOInterface idioma;
    private  CursoDAOInterface curso;
    private  ECTSDAOInterface ects;
    private  CommonDAOInterface comun;
    private  ConvalidacionDAOInterface convalidacion;
    private  String lang;
     
    private FachadaBD(){
        pool = ConnectionPool.getInstance();
        conn = pool.getConnection();  
        master = new MasterDAO(pool,conn);
        colaboracion = new ColaboracionDAO(pool,conn);
        idioma = new IdiomaDAO(pool,conn);
        curso = new CursoDAO(pool,conn);
        ects = new ECTSDAO(pool,conn);
        comun = new CommonDAO(pool,conn);
        convalidacion = new ConvalidacionDAO(pool,conn);
        lang = "es";
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
        this.master.setLang(lang);
        this.colaboracion.setLang(lang);
        this.idioma.setLang(lang);
        this.curso.setLang(lang);
        this.ects.setLang(lang);
        this.comun.setLang(lang);
        this.convalidacion.setLang(lang);
    }
     
    /**
     * Metodo Singleton para devolver una isntancia de la fachada.
     * 
     * @return objeto FachadaBD
     */
    public static FachadaBD getInstancia(){
        if(instancia==null){
             instancia= new FachadaBD();
             return instancia;
        }else{
            return instancia;
        }
    }
    
    /**
     * Metodo requestMasterList, devuelve un listado de los masters disponibles en la
     * BD.
     * 
     * @return objeto List  con el resultado
     */
    @Override
    public List<DTOMaster> requestMasterList() {
        return master.getAll();
       
    }
    
    /**
     * Metodo getNecesidadHomologacionMaster, devuelve la necesidad o no de homologar un máster.
     * 
     * @return objeto Boolean  con el resultado
     */
    @Override
    public Boolean getNecesidadHomologacionMaster(String programa) {
        boolean necesidad = false;
        necesidad = ((DTOMaster)master.get(programa)).isgHomologado();
        return necesidad;
    }
    
    /**
     * Metodo getGraduadoNecesarioHomologar, devuelve el grado homologado requerido para acceder al programa de master.
     * 
     * @return objeto String  con el resultado
     */
    @Override
    public String getGraduadoNecesarioHomologar(String titulo) {
        return getGradoAsociadoMaster(titulo);
    }
    
    /**
     * Metodo getGraduadoNecesarioAccesoProgramaMaster, devuelve el grado requerido para acceder al programa de master.
     * 
     * @return objeto String  con el resultado
     */
    @Override
    public String getGraduadoNecesarioAccesoProgramaMaster(String programa) {
        return getGradoAsociadoMaster(programa);
    }
    
    /**
     * Metodo getGradoAsociadoMaster, obtiene el grado necesario para acceder a 
     * un programa de master.
     * 
     * @param programa  El programa de master
     * @return String con el nombre del titulo necesario
     */
    private String getGradoAsociadoMaster(String programa){
        String grado =null;
        DTOMaster dtomaster = ((DTOMaster)master.get(programa));
        grado = dtomaster.getGrado();
        return grado;
    
    }
    
    /**
     * Metodo getColaboracionesMaster, obtiene las colaboracioens de entidades asociadas 
     * a un master especifico.
     * 
     * @param programa String con el nombre de programa de master
     * @return Objeto List<DTOColaboracion> con el listado de colaboraciones
     */
    @Override
    public List<DTOColaboracion> getColaboracionesMaster(String programa) {
          
        ArrayList<DTOColaboracion> resultado = (ArrayList)colaboracion.getColaboracionesDeUnMaster(programa);
        
        return resultado;
    }

    /**
     * Metodo getRespuestaSolicitudPaisAccesoMaster, obtiene la pregunta necesaria
     * para obtener el pais de la entidad expedidora de titulo de grado.
     * 
     * @return String con la pregunta
     */
    @Override
    public String getRespuestaSolicitudPaisAccesoMaster() {
        return master.getSolicitarPaisEntidadExpedidora();
    }

     /**
     * Metodo getSolicitudGradoHomologado, obtiene la pregunta necesaria
     * para obtener la pregunta asociada a solicitar si se posee un grado homologado.
     * 
     * @return String con la pregunta
     */
    @Override
    public String getSolicitudGradoHomologado() {
        return master.getPreguntaHomologacionTitulo();
    }
   
    /**
     * Metodo getPreguntaGrado, obtiene la pregunta necesaria
     * para obtener la pregunta asociada a solicitar si se posee un grado.
     * 
     * @return String con la pregunta
     */
    @Override
    public String getPreguntaGrado() {
        return master.getPreguntaGradoGeneral();
    }

    /**
    * Metodo getPreguntaGradoEspecifico, obtiene la pregunta necesaria
    * para obtener la pregunta asociada a solicitar si se posee un grado.
    * 
    * @return String con la pregunta
    */
    @Override
    public String getPreguntaGradoEspecifico() {
        return master.getPreguntaGradoEspecifica();
    }

    /**
    * Metodo getPreguntaGraduadoEspecificoHomologado, obtiene la pregunta necesaria
    * para obtener la pregunta asociada a solicitar si se posee un grado especifico homologado.
    * 
    * @return String con la pregunta
    */
    @Override
    public String getPreguntaGraduadoEspecificoHomologado() {
        return master.getPreguntaHomologacionTitulo();
    }

    /**
    * Metodo getRespuestaAceptacionMaster, obtiene la respuesta de indicación
    * de cumplimientode requisitos de acceso a master.
    * 
    * @return String con la respuesta
    */
    @Override
    public String getRespuestaAceptacionMaster() {
        return master.getRespuestaAceptacionAcceso()+"\n"+master.getUrlPreinscripcion();
    }

    /**
    * Metodo getListadoMasteresAlternativos, obtiene un listado de másteres que solo
    * requieren un graduado universitario para su acceso, sin importar el área de 
    * conocimiento.
    * 
    * @return List con el listado indicado
    */
    @Override
    public List<DTOMaster> getListadoMasteresAlternativos() {
        return master.getMasteresSinGraduadoEspecifico();
    }
   
    /**
    * Metodo getRespuestaNoAceptacionMaster, obtiene la respuesta de indicación
    * de no cumplimiento de requisitos de acceso a master.
    * 
    * @return String con la respuesta
    */
    @Override
    public String getRespuestaNoAceptacionMaster(){
        return master.getRespuestaNegacionAcceso();
    }
    
    /**
    * Metodo getRespuestaObligacionHomologacion, obtiene la respuesta de indicación
    * de no cumplimiento de requisitos de acceso a master.
    * 
    * @return String con la respuesta
    */
    @Override
    public String getRespuestaObligacionHomologacion() {
        return master.getRespuestaHomologacion()+"\n"+master.getUrlHomologacion();
    }

    /**
    * Metodo getIdiomasDeMaster, obtiene el conjunto de idiomas de imparticion de un
    * máster.
    * 
    * @param  programa String con el programa a consultar
    * @return List con la respuesta
    */
    @Override
    public List<DTOIdioma> getIdiomasDeMaster(String programa) {
        return master.getIdiomasSecundariosMaster(programa);
    }

     /**
    * Metodo getIdiomasDeMaster, obtiene el conjunto de idiomas de imparticion de un
    * máster.
    * 
    * @param  programa String con el programa a consultar
    * @param  idioma String con el idioma especifico a consultar
    * @return List con la respuesta
    */
    @Override
    public List<DTOIdioma> getIdiomasDeMaster(String programa, String idioma) {
        return master.getIdiomasSecundariosMaster(programa,idioma);
    }

    /**
     * Metodo getRespuestaIdiomasEncontrados, obtiene la respuesta correspondiente
     * a haber encontrado los idiomas de imparticion del master.
     * 
     * @return 
     */
    @Override
    public String getRespuestaIdiomasEncontrados() {
        return idioma.getRespuestaMasteresEncontrados();
    }
    
    
    /**
     * Metodo getRespuestaIdiomasNoEncontrados, obtiene la respuesta correspondiente
     * a no haber encontrado los idiomas de imparticion del master.
     * 
     * @return 
     */
    @Override
    public String getRespuestaIdiomasNoEncontrados() {
        return idioma.getRespuestaMasteresNoEncontrados();
    }

    /**
     * Metodo getPlantillaIdioma, proporcioan la plantilla de presentacion de idiomas. 
     * 
     * @return String con la plantilla
     */
    @Override
    public String getPlantillaIdioma() {
        return idioma.getPlantillaIdioma();
    }

    /**
     * Metodo getPresentacionPrecioMaster, proporciona la presentacion al usuario del precio
     * del master.
     * 
     * @return String con la cadena
     */
    @Override
    public String getPresentacionPrecioMaster() {
       return master.getPresentacionPrecioAprox();
    }

    /**
     * Metodo getPrecioMaster, obtiene el precio aproximado de un master.
     * 
     * @param programa El string con el programa de master
     * @return int con el precio aproximado
     */
    @Override
    public int getPrecioMaster(String programa) {
        return master.get(programa).getPrecioAproximado();
    }

    /**
     * Metodo getPresentacionPresencialidadMaster, obtiene lap resentacion de la
     * presencialidad del porgrama de master.
     * 
     * @return String con la frase de presentacion
     */
    @Override
    public String getPresentacionPresencialidadMaster() {
        return master.getPresentacionPresencialidadMaster();
    }

    /**
     * Metodo getPresencialidadMaster, devuelve la presencialidad asociada al master.
     * 
     * @param programa String con el programa de master
     * @return String con la presencialidad
     */
    @Override
    public String getPresencialidadMaster(String programa) {
        return master.get(programa).getPresencialidad();
    }

    /**
     * Metodo getExcepcionalidadPresencialidadMaster
     * 
     * @return 
     */
    @Override
    public String getExcepcionalidadPresencialidadMaster() {
        return master.getExcepcionalidadPresencialidad();
    }

    /**
     * Metodo getPresentacionCronogramaMaster, obtiene la frase de presentacion
     * del cronograma.
     * 
     * @return String con la frase
     */
    @Override
    public String getPresentacionCronogramaMaster() {
        return curso.getPresentacionCronogramaMaster();
    }

    /**
     * Metodo getCursosMaster, obtiene el listado de cursos asociados a un master.
     * 
     * @param programa String programa
     * @return List de cursos
     */
    @Override
    public List<DTOCurso> getCursosMaster(String programa) {
        ArrayList<DTOCurso> lista = (ArrayList<DTOCurso>) curso.getCursosMaster(programa);
        ArrayList<DTOCurso> copia = null;
        if(lista!=null){
            copia = new ArrayList();
            for(int i=0;i<lista.size();i++){
                DTOCurso c = lista.get(i);
                c.setMesFin(castNumbertoMonth(c.getNumMesFin()));
                c.setMesInicio(castNumbertoMonth(c.getNumMesInicio()));
                copia.add(c);
            }
        }
        return copia;
    }

    /**
     * Metodo getPlantillaCurso, obtiene la plantilla de datos de un curso para el
     * cronograma.
     * 
     * @return String con la platilla
     */
    @Override
    public String getPlantillaCurso() {
        return curso.getPlantillaCurso();
    }
    
    /**
     * Metodo getDescripcionMaster, obtiene la descripcion de un master.
     * 
     * @param programa El programa de master
     * @return String con la descripcion
     */
    @Override
    public String getDescripcionMaster(String programa) {
        return master.get(programa).getDescripcion();
    }
    /**
     * Metodo getPlantillaPresLProg, devuelve la plantilla de presentacion de los
     * lenguajes de programacion de un master.
     * 
     * @return String con la cadena
     */
    @Override
    public String getPlantillaPresLProg() {
        return master.getPlantillaPresLProg();
    }
    /**
     * Metodo getMaster, devuelve el DTO de un master.
     * 
     * @param programa String con el programa de master por el que se pregunta
     * @return DTOMaster
     */
    @Override
    public DTOMaster getMaster(String programa) {
        return master.get(programa);
    }
    /**
     * Metodo getPlantillaLProg, devuelve la plantilla de presentacion de lenguajes
     * de programacion de un master.
     * 
     * @return String con la plantilla
     */
    @Override
    public String getPlantillaLProg() {
        return master.getPlantillaLProg();
    }
    
    
    private String castNumbertoMonth(int num){
         String resp="";
         resp = new DateFormatSymbols().getMonths()[num-1];
         
        return resp;
    }
    /**
     * Metodo getDescripcionECTS, devuelve la descripcion de que es un credito ECTS.
     * 
     * @return String
     */
    @Override
    public String getDescripcionECTS() {
        return ects.getDescripcionCreditoECTS();
    }
 
    /**
     * Metodo getDefaultInteractionIntentFallback, devuelve la contestacion por 
     * defecto de no reconocimiento de intent.
     * 
     * @return String
     */
    public String getDefaultInteractionIntentFallback() {
        return comun.getDefaultInteractionIntentFallback();
    }

    /**
     * Metodo getDefaultInteractionServiceNotAvailable, devuelve la contestacion
     * por defecto.
     * 
     * @return String
     */
    public String getDefaultInteractionServiceNotAvailable() {
        return comun.getDefaultInteractionServiceNotAvailable();
    }

    /**
     * Metodo getDefaultInteractionMissingMasterInfo, devuelve la contestacion por
     * defecto de no hay masterasociado a la pregunta.
     * 
     * @return String
     */
    public String getDefaultInteractionMissingMasterInfo() {
       return comun.getDefaultInteractionMissingMasterInfo();
    }

    /**
     * Metodo getPresentacionColaboraciones, devuelve la presentacion de colaboracioens.
     * 
     * @return  String
     */
    @Override
    public String getPresentacionColaboraciones() {
         return colaboracion.getPresentacionColaboracionesMaster();
    }
    
    @Override
    public String getPresentacionColaboracionesAparte() {
         return colaboracion.getPresentacionColaboracionesAparte();
    }
    /**
     * Metodo getPlantillaColaboracion, obtiene plantilla de colaboracion de un master.
     * 
     * @return String
     */
    @Override
    public String getPlantillaColaboracion() {
        return colaboracion.getPlantillaColaboracion();
    }

    /**
     * Metodo getMensajeNoHayColaboraciones, obtiene el mensaje de colaboracion
     * no encontrada.
     * 
     * @return  String
     */
    @Override
    public String getMensajeNoHayColaboraciones() {
        return colaboracion.getMensajeNoColaboracion();
    }

    /**
     * Metodo getInfoConvalidacion, obtiene el mensaje de proceso de convalidacion.
     * 
     * @return String
     */
    @Override
    public String getInfoConvalidacion() {
        return convalidacion.getMensajeConvalidacion();
    }

    @Override
    public String getRespuestaNoHayLProg() {
        return master.getNoHayLProg();
    }

    @Override
    public String getContactoCoordinacion(String programa) {
       return master.get(programa).getcCoordinacion();
    }

    @Override
    public String getPresentacionCoordinacion() {
        return master.getPresentacionCoordinacion();
    }
}
