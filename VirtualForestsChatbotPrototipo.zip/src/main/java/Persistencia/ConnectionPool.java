package Persistencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Clase ConnectionPool, gestiona el pool de conexiones con BD.
 * 
 * @author JAA
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
import javax.sql.DataSource;
import javax.naming.InitialContext;

public class ConnectionPool {
    
    private static ConnectionPool pool = null;
    
    /**
     * Cosntructor de clase.
     * 
     */
    private ConnectionPool() {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println("Derby driver not found.");
        }
      
    }

    /**
     * Metodo Singleton para obtecion de instancia de ConnectionPool.
     * 
     * @return objeto ConnectionPool
     */
    public static ConnectionPool getInstance() {
        if (pool == null) {
            pool = new ConnectionPool();
        }
        return pool;
    }

    /**
     * Metodo getConnection, devuelve una conexion estable con la BD.
     * 
     * @return  objeto Connection con la BD
     */
    public Connection getConnection() {
         
        Properties prop = new Properties(); 
        try {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            prop.load(classloader.getResourceAsStream("DatabaseProperties.properties"));
            String url = (String)prop.get("jdbc");
            String user = (String)prop.get("user");
            String psswd = (String)prop.get("psswd");
            return DriverManager.getConnection(url,user,psswd);
        } catch (Exception exp) {
            exp.printStackTrace();
            return null;
        }
    }

    /**
     * Metodo freeConnection, libera una conexion estable con la BD.
     * 
     * @param c Objeto Connection con la conexion a liberar
     */
    public void freeConnection(Connection c) {
        try {
            c.close();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }
}