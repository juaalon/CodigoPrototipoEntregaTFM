 
package Persistencia;
 
import Comun.DTO.DTOMaster;
import java.util.List;

/**
 * Interfaz con la fachada de Persistencia del CU Informar Planes Master
 * 
 * @author JAA
 */
public interface CUFachadaInformarPlanesMaster {
    List<DTOMaster> requestMasterList() ;
}
