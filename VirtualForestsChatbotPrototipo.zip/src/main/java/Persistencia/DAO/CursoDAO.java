/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOCurso;
import Persistencia.ConnectionPool;
import Persistencia.StructRespuestas.RespuestasConsultarCronogramaStruct;
import Persistencia.StructRespuestas.RespuestasIdiomasMasterStruct;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author usuario
 */
public class CursoDAO implements CursoDAOInterface{
    private  ConnectionPool pool;
    private  Connection conn;
    private  Gson gson;
    private String lang;

    public CursoDAO(ConnectionPool pool,Connection conn){
        this.pool = pool;
        this.conn = conn;
        this.gson = new Gson();
    }
     @Override
    public void setLang(String lang){
        this.lang=lang;
    }

     private RespuestasConsultarCronogramaStruct getReader() throws IOException{
          String filePath = "/"+lang+"/RespuestasCronogramaMaster.json";
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
          
         return gson.fromJson(reader, RespuestasConsultarCronogramaStruct.class );
    }
    
    @Override
    public Object get(Object programaMaster) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void save(Object t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Object t, String[] params) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getPresentacionCronogramaMaster() {
       String presentacion = null;
       try{
            presentacion = getReader().getPresentacionCronograma();
       }catch(Exception excp){
           excp.printStackTrace();
       }
       return presentacion;
    }

    @Override
    public List<DTOCurso> getCursosMaster(String programa) {
       String query = "SELECT  C.NUMERACION, C.MESINICIO, C.MESFIN, C.CREDITOS, C.MASTER\n"
        + "FROM  CURSO AS C , MASTERES AS M WHERE  M.NOMBRE LIKE ? AND M.ID = C.MASTER\n";
        DTOCurso curso = null;
        ArrayList<DTOCurso> listado = null;
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, (String)programa);
            ResultSet set = statement.executeQuery();
            listado = new ArrayList();
            while(set.next()){
                curso = new DTOCurso(set.getInt("NUMERACION"),set.getInt("MESINICIO"),set.getInt("MESFIN"),set.getInt("CREDITOS"),set.getString("MASTER"));
                listado.add(curso);
            } 
        }catch(Exception e){
           listado = null;
        }
        return listado;
    }

    @Override
    public String getPlantillaCurso() {
       String plantilla = null;
       try{
            plantilla = getReader().getPlantillaCurso();
       }catch(Exception excp){
           excp.printStackTrace();
       }
       return plantilla;
    }
    
}
