/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Persistencia.StructRespuestas.RespuestasPrecioMasterStruct;
import Persistencia.StructRespuestas.RespuestasAccesoMasterStruct;
import Comun.DTO.DTOIdioma;
import Comun.DTO.DTOMaster;
import Persistencia.ConnectionPool;
import Persistencia.StructRespuestas.RespuestasCoordinacionMasterStruct;
import Persistencia.StructRespuestas.RespuestasLProgMasterStruct;
import Persistencia.StructRespuestas.RespuestasPresencialidadMasterStruct;
import com.google.gson.Gson;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
 
 

/**
 *
 * @author usuario
 */
public class MasterDAO implements MasterDAOInterface{
    private  ConnectionPool pool;
    private  Connection conn;
    private  Gson gson;
    private String lang;
    
    public MasterDAO(ConnectionPool pool,Connection conn){
        this.pool = pool;
        this.conn = conn;   
        this.gson = new Gson();
       
    }
    @Override
    public void setLang(String lang){
        this.lang = lang;
       
    }
    
    @Override
    public  DTOMaster get(Object id) {
       String query = "SELECT *\n"
        + "FROM MASTERES AS M WHERE M.NOMBRE LIKE ?\n";
         DTOMaster master = null;
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, (String)id);
            ResultSet set = statement.executeQuery();
           
            while(set.next()){
                master = new DTOMaster(set.getInt("ID"),set.getInt("CODIGOPLAN"),set.getString("NOMBRE"),set.getString("DESCRIPCION"),set.getInt("PRECIOAPROXIMADO"),set.getString("PRESENCIALIDAD"),set.getBoolean("DOBLETITULACION"),set.getBoolean("GHOMOLOGADO"),set.getString("GRADO"),set.getString("IDIOMAPRINCIPAL"),set.getString("IDIOMASECUNDARIO"), set.getString("LPROGPRINCIPAL"), set.getString("LPROGSECUNDARIO"), set.getString("CCOORDINACION"));
                
            }
            
        }catch(Exception e){
           e.printStackTrace();
        }
         return master;
    }

    @Override
    public List<DTOMaster> getAll() {
         
        String query = "SELECT *\n"
        + "FROM MASTERES AS M\n";
        List listado = new ArrayList<DTOMaster>();
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            ResultSet set = statement.executeQuery();
            DTOMaster master;
            while(set.next()){
                master = new DTOMaster(set.getInt("ID"),set.getInt("CODIGOPLAN"),set.getString("NOMBRE"),set.getString("DESCRIPCION"),set.getInt("PRECIOAPROXIMADO"),set.getString("PRESENCIALIDAD"),set.getBoolean("DOBLETITULACION"),set.getBoolean("GHOMOLOGADO"),set.getString("GRADO"),set.getString("IDIOMAPRINCIPAL"),set.getString("IDIOMASECUNDARIO"), set.getString("LPROGPRINCIPAL"), set.getString("LPROGSECUNDARIO"), set.getString("CCOORDINACION"));
                listado.add(master);
            }
            
        }catch(Exception e){
           listado = null;
        }
         return listado;
    }
    
    @Override
    public List<DTOMaster> getMasteresSinGraduadoEspecifico() {
         
        String query = "SELECT *\n"
        + "FROM MASTERES AS M WHERE GHOMOLOGADO GHOMOLOGADO = '0'\n";
        List listado = new ArrayList<DTOMaster>();
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            ResultSet set = statement.executeQuery();
            DTOMaster master;
            while(set.next()){
                master = new DTOMaster(set.getInt("ID"),set.getInt("CODIGOPLAN"),set.getString("NOMBRE"),set.getString("DESCRIPCION"),set.getInt("PRECIOAPROXIMADO"),set.getString("PRESENCIALIDAD"),set.getBoolean("DOBLETITULACION"),set.getBoolean("GHOMOLOGADO"),set.getString("GRADO"),set.getString("IDIOMAPRINCIPAL"),set.getString("IDIOMASECUNDARIO"), set.getString("LPROGPRINCIPAL"), set.getString("LPROGSECUNDARIO"), set.getString("CCOORDINACION"));
                listado.add(master);
            }
            
        }catch(Exception e){
           listado = null;
        }
         return listado;
    }
    
    @Override
    public List<DTOIdioma> getIdiomasSecundariosMaster(String programa) {
         
        String query = "SELECT  M.IDIOMASECUNDARIO, I.DESIGNACION, I.NIVELMINIMO, I.NIVELRECOMENDADO\n"
        + "FROM MASTERES AS M, IDIOMA AS I WHERE M.IDIOMASECUNDARIO = I.DESIGNACION AND M.NOMBRE LIKE ?\n";
        List listado = new ArrayList<DTOIdioma>();
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, (String)programa);
            ResultSet set = statement.executeQuery();
            DTOIdioma idioma;
            while(set.next()){
                idioma = new DTOIdioma(set.getString("DESIGNACION"),set.getString("NIVELMINIMO"),set.getString("NIVELRECOMENDADO"));
                listado.add(idioma);
                 
            } 
        }catch(Exception e){
           listado = null;
        }
        return listado;
    }
    
    @Override
    public List<DTOIdioma> getIdiomasSecundariosMaster(String programa,String idioma) {
          
        String query = "SELECT  M.IDIOMASECUNDARIO, I.DESIGNACION, I.NIVELMINIMO, I.NIVELRECOMENDADO\n"
        + "FROM MASTERES AS M, IDIOMA AS I WHERE M.IDIOMASECUNDARIO = I.DESIGNACION AND M.NOMBRE LIKE ? AND I.DESIGNACION LIKE ?\n";
        List listado = new ArrayList<DTOIdioma>();
        try{
            PreparedStatement statement;
            statement= conn.prepareStatement(query);
            statement.setString(1, (String)programa);
            statement.setString(2, (String)idioma);
            ResultSet set = statement.executeQuery();
            DTOIdioma idiomas;
            while(set.next()){
                idiomas = new DTOIdioma(set.getString("DESIGNACION"),set.getString("NIVELMINIMO"),set.getString("NIVELRECOMENDADO"));
                listado.add(idiomas);
            } 
        }catch(Exception e){
           listado = null;
        }
        return listado;
    }
    
    private RespuestasAccesoMasterStruct getReaderAccesoMaster() throws IOException{
        
         String filePath ="/"+lang+"/RespuestasAccesoMaster.json";  
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         return gson.fromJson(reader, RespuestasAccesoMasterStruct.class );
    }
     private RespuestasPrecioMasterStruct getReaderPrecioMaster() throws IOException{
     
         String filePath ="/"+lang+"/RespuestasPrecioMaster.json"; 
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         return gson.fromJson(reader, RespuestasPrecioMasterStruct.class ); 
         
    }
      private RespuestasPresencialidadMasterStruct getReaderPresencialidadMaster() throws IOException{
         
         String filePath ="/"+lang+"/RespuestasPresencialidadMaster.json"; 
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         return gson.fromJson(reader, RespuestasPresencialidadMasterStruct.class );  
         
    }
       private RespuestasLProgMasterStruct getReaderLProgMaster() throws IOException{
          
         String filePath ="/"+lang+"/RespuestasLProgMaster.json"; 
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         return gson.fromJson(reader, RespuestasLProgMasterStruct.class );   
 
    }
       
          private RespuestasCoordinacionMasterStruct getReaderCoordMaster() throws IOException{
          
         String filePath ="/"+lang+"/RespuestasCoordinacionMaster.json"; 
         ClassLoader classloader = Thread.currentThread().getContextClassLoader();
         Reader reader =   new InputStreamReader(classloader.getResourceAsStream(filePath));
         return gson.fromJson(reader, RespuestasCoordinacionMasterStruct.class );   
 
    }
     
    @Override 
    public String getUrlPreinscripcion() {
        String urlPreinscripcion = null;
        try{
           
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            urlPreinscripcion = objectRequest.getUrlPreinscripcion();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return urlPreinscripcion;
    }

     
    @Override
    public String getUrlHomologacion() {
        String urlHomologacion = null;
        try{
            
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            urlHomologacion = objectRequest.getUrlHomologacion();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return urlHomologacion;
    }

     
    @Override
    public String getPreguntaGradoGeneral() {
        String preguntaGradoGeneral = null;
        try{
             
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            preguntaGradoGeneral = objectRequest.getPreguntaGradoGeneral();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return preguntaGradoGeneral;
    }
    
    @Override
    public String getPreguntaGradoEspecifica() {
        String preguntaGradoEspecifica = null;
        try{
             
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            preguntaGradoEspecifica = objectRequest.getPreguntaGradoEspecifica();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return preguntaGradoEspecifica;
    }

    
    @Override
    public String getPreguntaHomologacionTitulo() {
       
        String preguntaHomologacionTitulo = null;
        try{
             
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            preguntaHomologacionTitulo = objectRequest.getPreguntaHomologacionTitulo();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return preguntaHomologacionTitulo;
    }

    @Override    
    public String getSolicitarPaisEntidadExpedidora() {
         
        String solicitarPaisEntidadExpedidora = null;
        try{
             
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            solicitarPaisEntidadExpedidora = objectRequest.getSolicitarPaisEntidadExpedidora();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return solicitarPaisEntidadExpedidora;
    }
 
    @Override
    public String getRespuestaAceptacionAcceso() {
        
        String respuestaAceptacionAcceso = null;
        try{
            
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            respuestaAceptacionAcceso = objectRequest.getRespuestaAceptacionAcceso();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuestaAceptacionAcceso;
    }

    @Override
    public String getRespuestaNegacionAcceso() {
        
        String respuestaNegacionAcceso = null;
        try{
            
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            respuestaNegacionAcceso = objectRequest.getRespuestaNegacionAcceso();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuestaNegacionAcceso;
    }

     
    @Override
    public String getRespuestaHomologacion() {
         
        String respuestaHomologacion = null;
        try{
            
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            respuestaHomologacion = objectRequest.getRespuestaHomologacion();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return respuestaHomologacion;
    }
 
    @Override
    public String getPosibilidadInscripcion() {
         
        String posibilidadInscripcion = null;
        try{
            
            RespuestasAccesoMasterStruct objectRequest = getReaderAccesoMaster();
            posibilidadInscripcion = objectRequest.getPosibilidadInscripcion();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return posibilidadInscripcion;
    }
    
     @Override
    public String getPresentacionPrecioAprox() {
         String presentacionPrecioAprox = null;
        try{
            
            RespuestasPrecioMasterStruct objectRequest = getReaderPrecioMaster();
            presentacionPrecioAprox = objectRequest.getPresentacionPrecioMaster();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return presentacionPrecioAprox;
    }
  @Override
    public String getPresentacionPresencialidadMaster() {
         String presentacionPresencialidad = null;
        try{
            
            RespuestasPresencialidadMasterStruct objectRequest = getReaderPresencialidadMaster();
            presentacionPresencialidad = objectRequest.getPresentacionPresencialidad();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return presentacionPresencialidad;
        
    }

    @Override
    public String getExcepcionalidadPresencialidad() {
         String excepcionalidadPresencialidad = null;
        try{
            
            RespuestasPresencialidadMasterStruct objectRequest = getReaderPresencialidadMaster();
            excepcionalidadPresencialidad = objectRequest.getExcepcionalidadPresencialidad();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return excepcionalidadPresencialidad;
    }

 @Override
    public String getPlantillaPresLProg() {
       String presentacionLProg = null;
        try{
            
            RespuestasLProgMasterStruct objectRequest = getReaderLProgMaster();
            presentacionLProg = objectRequest.getPresentacionLProg();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return presentacionLProg;
    }

    @Override
    public String getPlantillaLProg() {
        String plantilla = null;
        try{
            
            RespuestasLProgMasterStruct objectRequest = getReaderLProgMaster();
            plantilla = objectRequest.getPlantillaLProg();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return plantilla;
    }
    
    
    @Override
    public String getNoHayLProg() {
       String plantilla = null;
        try{
            
            RespuestasLProgMasterStruct objectRequest = getReaderLProgMaster();
            plantilla = objectRequest.getNoHayLenguajes();
        }catch(Exception excp){
            excp.printStackTrace();
        }
        return plantilla;
    }
     
     @Override
    public String getPresentacionCoordinacion() {
        try {
            return getReaderCoordMaster().getPresentacionCoordinacion();
        } catch (IOException ex) {
            return null;
        }
    }
    
    @Override
    public void save(DTOMaster t) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void update(DTOMaster t, String[] params) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void delete(DTOMaster t) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

   


   

  
   
    
 
    
}
