/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOCurso;
import java.util.List;

/**
 *
 * @author usuario
 */
public interface CursoDAOInterface extends DAOInterface {

    public String getPresentacionCronogramaMaster();

    public List<DTOCurso> getCursosMaster(String programa);

    public String getPlantillaCurso();

   
    
}
