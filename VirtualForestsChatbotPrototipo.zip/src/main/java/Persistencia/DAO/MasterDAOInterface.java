/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia.DAO;

import Comun.DTO.DTOIdioma;
import Comun.DTO.DTOMaster;
import java.util.List;

/**
 *
 * @author usuario
 */
public interface MasterDAOInterface extends DAOInterface<DTOMaster> {
    public String getRespuestaHomologacion();
    public String getPosibilidadInscripcion();
    public String getRespuestaNegacionAcceso();
    public String getRespuestaAceptacionAcceso();
    public String getSolicitarPaisEntidadExpedidora();
    public String getPreguntaHomologacionTitulo();
    public String getPreguntaGradoEspecifica();
    public String getPreguntaGradoGeneral();
    public String getUrlHomologacion();
    public String getUrlPreinscripcion();
    public List<DTOMaster> getMasteresSinGraduadoEspecifico();
    public List<DTOIdioma> getIdiomasSecundariosMaster(String programa);
    public List<DTOIdioma> getIdiomasSecundariosMaster(String programa,String idioma);

    public String getPresentacionPrecioAprox();

    public String getPresentacionPresencialidadMaster();

    public String getExcepcionalidadPresencialidad();

    public String getPlantillaPresLProg();

    public String getPlantillaLProg();

    public void setLang(String lang);

    public String getNoHayLProg();

    public String getPresentacionCoordinacion();
}
